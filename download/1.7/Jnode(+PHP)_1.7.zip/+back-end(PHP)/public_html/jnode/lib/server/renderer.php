<?php
require_once "autoload.php";

$jnode = new Gurumdari\Jnode();
$jnode->registMods();
$jnode->checkHTML5();

if (__FILE__ == $jnode::$HTML_HOME.$_SERVER["REQUEST_URI"]) {
	$jnode->sendError(404);
} else {
	$template   = "html";
	$page_id    = $_SERVER["REQUEST_URI"];
	$path_index = strrpos($page_id, "/");
	$ext_index  = strrpos($page_id, ".");

	if (($ext_index === false) || ($path_index > $ext_index)) {
		if (mb_substr($page_id, -1) == "/") {
			$page_id = $page_id."index";
		} else {
			$page_id = $page_id."/index";
		}
	} else {
		$page_id = mb_substr($page_id, 0, $ext_index);
	}

	if (isset($_GET["template"]))  $template = $_GET["template"];

	$jnode->requirePage($page_id, $template);
}