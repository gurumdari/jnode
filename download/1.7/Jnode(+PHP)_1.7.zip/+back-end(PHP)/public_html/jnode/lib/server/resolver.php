<?php
require_once "autoload.php";

$jnode = new Gurumdari\Jnode();
$jnode->registMods();
$jnode->checkHTML5();

if (__FILE__ == $jnode::$HTML_HOME.$_SERVER["REQUEST_URI"] || $_SERVER["REQUEST_METHOD"] != "POST") {
	$jnode->sendError(404);
} else {
	$template = strtolower(pathinfo($_SERVER["REQUEST_URI"])["extension"]);

	$require_type = $_POST["requireType"];
	$node_type    = $_POST["nodeType"];
	$node_id      = isset($_POST["nodeId"]) ? $_POST["nodeId"] : "/index";

	if (mb_substr($node_id, 0, 1) != "/")  $node_id = "/".$node_id;

	if ($require_type == "content") {
		// NOTE: In PHP, the dot (.) Can not be used and is replaced with an underscore (_), so the error.status_code changes to error_status_code.
		if (empty($_POST["error_status_code"])) {
			$jnode->requireContent($node_type, $node_id, $template);
		} else {
			$error_info = [
				"status_code" => intval($_POST["error_status_code"]),
				"template"    => $template
			];

			if (isset($_POST["error_message"]    ))  $error_info["message"]     = $_POST["error_message"];
			if (isset($_POST["error_stack"]      ))  $error_info["stack"]       = $_POST["error_stack"];
			if (isset($_POST["error_request_uri"]))  $error_info["request_uri"] = $_POST["error_request_uri"];
			if (isset($_POST["error_template"]   ))  $error_info["template"]    = $_POST["error_template"];
			// if (isset($_POST["error_html_message"]))  $error_info["html_message"] = $_POST["error_html_message"];

			$jnode->sendContentError($node_type, $error_info);
		}
	} else {
		require $jnode::$TEMPLATE_PATH."/controller/".$node_type.".ejs";
	}
}