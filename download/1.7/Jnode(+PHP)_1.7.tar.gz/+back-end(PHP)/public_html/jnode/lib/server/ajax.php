<?php
require_once "autoload.php";

$jnode = new Gurumdari\Jnode();
$jnode->registMods();

if (__FILE__ == $jnode::$HTML_HOME.$_SERVER["REQUEST_URI"]) {
	$jnode->sendError(404);
} else {
	$jnode->requireAJAX();
}