<?php
require_once "autoload.php";

$jnode = new Gurumdari\Jnode();
$jnode->checkHTML5();

if (__FILE__ == $jnode::$HTML_HOME.$_SERVER["REQUEST_URI"]) {
	$jnode->sendError(404);
} else {
	$status_code = 500;

	if (isset($_GET["status"]))  $status_code = intVal($_GET["status"]);
	if ($status_code == 0)       $status_code = 500;

	$jnode->sendError($status_code);
}