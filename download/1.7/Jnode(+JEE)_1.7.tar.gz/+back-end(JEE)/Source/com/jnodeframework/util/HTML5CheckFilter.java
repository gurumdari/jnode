/*
 * @(#)HTML5CheckFilter.java  1.0, 2014-10-10
 */
package com.jnodeframework.util;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Filter to check if you are connected to a browser that supports HTML5.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class HTML5CheckFilter implements Filter {

	/**
	 * The configuration object for the filter setting.
	 */
	private FilterConfig filterConfig = null;

	/**
	 * Called by the web container to use the filter service.
	 */
	public void init(FilterConfig filterConfig) {
		this.filterConfig = filterConfig;
	}

	/**
	 * Called by the web container to terminate the filter service.
	 */
	public void destroy() {
		this.filterConfig = null;
	}

	/**
	 * This checks if client are connected with a browser that supports HTML5.
	 */
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest  request  = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse)res;

		String requestURI  = request.getRequestURI();
		String contextPath = request.getContextPath();
		String requestUriWoContextPath = requestURI.substring(contextPath.length());

		boolean skipHTML5Check = false;

		String joinedExclude = filterConfig.getInitParameter("exclude");
		String acceptIe      = filterConfig.getInitParameter("accept_ie");
		String[] excludes    = null;

		if (joinedExclude != null)  excludes = joinedExclude.trim().split("\n");

		for (String exclude : excludes) {
			exclude = exclude.trim();

			if (!exclude.equals("")) {
				if (exclude.endsWith("*")) {
					if (requestUriWoContextPath.startsWith(exclude.substring(0, exclude.length() - 1))) {
						skipHTML5Check = true;
						break;
					}
				} else if (exclude.startsWith("*")) {
					if (requestUriWoContextPath.endsWith(exclude.substring(1))) {
						skipHTML5Check = true;
						break;
					}
				} else {
					if (requestUriWoContextPath.equals(exclude)) {
						skipHTML5Check = true;
						break;
					}
				}
			}
		}

		if (skipHTML5Check) {
			chain.doFilter(request, response);
		} else {
			String userAgent       = request.getHeader("user-agent");
			String detectedBrowser = "ie";

			// When accessing URL Open, there may be no user-agent.
			if (userAgent == null)  userAgent = "";

			boolean acceptClient = true;

			int   acceptIeVersion = 0;
			float msieVersion     = 8;

			if (acceptIe != null) {
				try {
					// It is cast to int so that it can only be get as an integer.
					acceptIeVersion = Integer.parseInt(acceptIe);

					if (acceptIeVersion < 9 || acceptIeVersion > 11)  acceptIeVersion = 0;
				} catch(Exception e) {}
			}

			// IE, if Trident or IE is searched.
			if (userAgent.indexOf("Trident") > -1 || userAgent.indexOf("MSIE") > -1) {
				// "MSIE\\s\\d+\\.\\d+"
				// WinXP  IE 6.0:   Mozilla/4.0 (Windows; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)
				// WinXP  IE 7.0:   Mozilla/4.0 (Windows; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)
				// WinXP  IE 8.0:   Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)
				// Win7   IE 11.0:  Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko
				// Win8.1 IE 11.0:  Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko
				// Win10  IE 11.0:  Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko
				// Compatible mode: Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; InfoPath.3)
				// MSIE 6.0    -> IE6
				// MSIE 7.0    -> IE7
				// Trident/4.0 -> IE8
				// Trident/5.0 -> IE9
				// Trident/6.0 -> IE10
				// Trident/7.0 -> IE11

				Matcher tridentMatcher = Pattern.compile("Trident\\/(\\d+\\.\\d+)").matcher(userAgent);
				if (tridentMatcher.find()) {
					// Since there is compatibility view, check with Trident version, not IE version. The difference between the two is 4.
					msieVersion = Float.parseFloat(tridentMatcher.group(1)) + 4;
				} else {
					Matcher msieMatcher = Pattern.compile("MSIE\\s(\\d+\\.\\d+)").matcher(userAgent);
					if (msieMatcher.find()) {
						msieVersion = Float.parseFloat(msieMatcher.group(1));
					}
				}

				if (acceptIeVersion == 0 || msieVersion < acceptIeVersion) {
					acceptClient = false;
				}

				response.setHeader("X-UA-Compatible", "IE=Edge");
			} else if (userAgent.indexOf("Navigator") > -1) {
				// WinXP:    Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.12) Gecko/20080219 Firefox/2.0.0.12 Navigator/9.0.0.6
				// Mac OS X: Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; en-US; rv:1.8.1.12) Gecko/20080219 Firefox/2.0.0.12 Navigator/9.0.0.6
				// Linux:    Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.1.12) Gecko/20080219 Firefox/2.0.0.12 Navigator/9.0.0.6
				acceptIeVersion = 0;
				detectedBrowser = "navigator";
				acceptClient    = false;

				// Konqueror
				// Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.34 (KHTML, like Gecko) konqueror/4.14.13 Safari/534.34
				// Mozilla/5.0 (X11; Linux x86_64) KHTML/4.14.13 (like Gecko) Konqueror/4.14
			}

			/*
			Chrome 14 and higher
			Firefox 7 and higher
			Opera 11 and higher
			Safari 5 and higher
			-----------------------------
			Mobile Safari 3.2 and higher
			Opera Mobile 5 and higher
			Android 2.1 and higher
			*/

			if (acceptClient) {
				chain.doFilter(request, response);
			} else {
				String alterBrowser = "";
				float ntVersion = 6;  // Based on Windows 7

				if (userAgent.indexOf("Windows NT") > -1) {
					Matcher windowsMatcher = Pattern.compile("Windows NT (\\d+\\.\\d+)").matcher(userAgent);
					if (windowsMatcher.find()) {
						ntVersion = Float.parseFloat(windowsMatcher.group(1));
						if (ntVersion > 9) {
							alterBrowser    = "Edge";
							if (detectedBrowser.equals("ie"))  detectedBrowser = "edge";
						}
					}
				} else if (userAgent.indexOf("Mac OS X") > -1) {
					alterBrowser = "Safari";
				}

				request.setAttribute("detected_browser", detectedBrowser);
				request.setAttribute("accept_version"  , (acceptIeVersion == 0 ? "" : String.valueOf(acceptIeVersion)));
				request.setAttribute("alter_browser"   , alterBrowser);
				request.setAttribute("support_html5"   , (msieVersion > 8 ? "html5" : ""));

				String guideMessage = "";

				if (acceptIeVersion > 8) {
					guideMessage = "Please use another browser that supports HTML5 if you are unable to use internet explorer ver." + acceptIeVersion + " or higher.";
				} else if (alterBrowser.equals("")) {
					guideMessage = "Please use another browser that supports HTML5.";
				} else {
					guideMessage = "Please use " + alterBrowser + " or another browser that supports HTML5.";
				}

				request.setAttribute("guide_message", guideMessage);

				if (detectedBrowser.equals("navigator"))  response.sendError(415, "You cannot access with Netscape Navigator.");
				else if (acceptIeVersion ==  0)           response.sendError(415, "You cannot access with Internet Explorer.");
				else if (acceptIeVersion ==  9)           response.sendError(415, "Please check if your browser supports HTML5.");
				else                                      response.sendError(415, "You should access with internet explorer ver." + acceptIeVersion + " or higher.");
			}
		}
	}
}