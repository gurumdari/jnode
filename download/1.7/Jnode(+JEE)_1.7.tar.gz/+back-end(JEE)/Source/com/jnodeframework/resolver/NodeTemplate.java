/*
 * @(#)NodeTemplate.java  1.0, 2014-10-10
 */
package com.jnodeframework.resolver;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet that configures the template file to process the node element of the web application to be found in the path (/WEB-INF/template/content) managed by the JEE Server.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class NodeTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The template file to process the node element responds only when requested by the POST method.
	 * When requesting by the GET method, the 404 error page is output instead of the 405 error page,
	 * and it makes it impossible to know whether or not there is an actual template file when request method is abnormal.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendError(404, "File Not Found");
	}

	/**
	 * The template file to process the node element of the web application is found
	 * and output from the path (/WEB-INF/template/content) managed by JEE Server.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String template = getServletConfig().getInitParameter("template");
		String encoding = getServletConfig().getInitParameter("encoding");

		new TemplateResolver(request, response, template).resolveTemplate((String)null, encoding);
	}
}