/*
 * @(#)ImageFileServlet.java  1.7, 2017-04-04
 */
package com.jnodeframework.resolver;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// import org.apache.commons.codec.binary.Base64;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

/**
 * Servlet that does not upload the image file of the client, or store the image file read from the URL of the other domain in the special path of the Web application server,
 * and transforms an image into a Base64 string that can be used only by internal code of the template file (HTML, JSP, EJS, ...).
 * 
 * It is called with the URL pattern "/jnode/proxy/image_file.html" registered in WebServlet annotation.
 * Up to version 1.6 of the Jnode Framework, WebServlet annotation was registered with the URL pattern "/servlet/com.jnodeframework.resolver.ImageFileServlet".
 * However, since version 1.7 of the Jnode Framework, we have changed the URL pattern to "/jnode/proxy/image_file.html"
 * to eliminate the dependency of the back-end environment when supporting PHP interpreter.
 * 
 * ImageFileServlet reads an image file in two ways.
 * If the encoding type is requested by multipart/form-data, the image file uploaded from the client is read and output.
 * When the encoding type is requested by application/x-www-form-urlencoded,
 * and the image file corresponding to the url is read when the URL address to read the image file is passed as the url parameter.
 * 
 * 
 * [Image file upload processing]
 * 
 * If the encoding type is passed to multipart/form-data, the image file is assumed to have been uploaded from the client,
 * converted to a Base64 string, and forwarded to the page corresponding to the parameter forward_uri containing the parameter information
 * with the name jnode_param in the attribute of the request.
 * Therefore, if the uploaded file is not an Image, an error occurs. If an error occurs, an error message is included in the request attribute with the name error_message.
 * 
 * The parameters used internally are as follows.
 * If parameters with the same name as those used internally are needed, you can store them in the next values of the array.
 * 
 * <UL>
 *   <LI><CODE>forward_uri</CODE> - The URL address to be forwarded after containing the parameter passed to the multipart/form-data encoding type as jnode_param.</LI>
 *   <LI><CODE>rewidth</CODE> - The width of the uploaded image file to change.</LI>
 *   <LI><CODE>reheight</CODE> - The height of the uploaded image file to change.</LI>
 * </UL>
 * 
 * The index of the rewidth and reheight array corresponding to the field name index of the uploaded image file are used as the width and height of the size to be changed.
 * If the rewidth or reheight number is smaller than the field name of the uploaded image file, the rewidth or reheight value is used as the value of the last array.
 * If there is no rewidth or reheight value, the size is not changed. The resizable images are PNG, JPEG, and GIF, and the rest of the images are converted to Base64-based strings only.
 * However, even if the field names of the same uploaded image file are plural, rewidth or reheight is processed only by one array index.
 * 
 * In this case, rewidth or reheight is intended to prevent the use of images that are too big than the actual image size available.
 * Therefore, if the width and height of the uploaded image are smaller than rewidth and reheight, respectively, the size conversion operation is not performed.
 * Also, if both rewidth and reheight are set to maintain the ratio of width to height of the original image, the value will be changed to a smaller value in consideration of the aspect ratio.
 * 
 * The parameters are stored in jnode_param with the following rules.
 * Up to Jnode Framework version 1.6, the name of multipart_param, but since version 1.7 PHP Interpeter support was unified as jnode_param.
 * 
 * <UL>
 *   <LI>Single general parameter - In Map&lt;String, String&gt; format, field name contains field value.</LI>
 *   <LI>Multiple general parameters - In Map&lt;String, String[]&gt; format, field name contains an array of field values.</LI>
 *   <LI>Single upload file parameter - In Map&lt;String, Map&lt;String, Object&gt;&gt; format, field name contains image file information.</LI>
 *   <LI>Multiple upload file parameter - In Map&lt;String, Map&lt;String, Object&gt;[]&gt; format, field name contains an array of image file information.</LI>
 * </UL>
 * 
 * The information of the uploaded image file is put in the following key.
 * 
 * <UL>
 *   <LI><CODE>name</CODE> - The name of the uploaded image file.</LI>
 *   <LI><CODE>value</CODE> - The String value obtained by converting the content of the uploaded image file to Base64.</LI>
 *   <LI><CODE>inputStream</CODE> - The InputStream value of the content of the uploaded image file. If you do not want to convert the image to Base64, you can manipulate the image directly via inputStream.</LI>
 *   <LI><CODE>contentType</CODE> - The content type of the uploaded file.</LI>
 *   <LI><CODE>size</CODE> - The long value of the uploaded file's size.</LI>
 * </UL>
 * 
 * 
 * [Proxy processing of image file of URL like local domain]
 * 
 * If the encoding type is passed to application/x-www-form-urlencoded, it is assumed that the image file of the URL wants to be converted to a Base64 string,
 * and the image corresponding to the url parameter is converted to a Base64 string image and output.
 * Internally used parameters are as follows, and other values are used as parameters to call the URL corresponding to the url parameter.
 * If a parameter with the same name as an internally used parameter is needed, it is stored in the next value of the array.
 * 
 * <UL>
 *   <LI><CODE>url</CODE> - URL address from which to read the image file.</LI>
 *   <LI><CODE>contenttype</CODE> - The content type of the request to read the image file of the URL address.</LI>
 *   <LI><CODE>accept</CODE> - The accept type of the response to read the image file of the URL address.</LI>
 *   <LI><CODE>rewidth</CODE> - The width of the URL image file to change.</LI>
 *   <LI><CODE>reheight</CODE> - The height of the URL image file to change.</LI>
 * </UL>
 * 
 * The ImageFileServlet internally prints a "Not allowed from the cross domain" message when exporting to a 403 status code when requested from another domain.
 * Therefore, similar to the processing inside ImageFileServlet, if the page corresponding to url is processed to reject another domain request, the page can not be read.
 * 
 * @version 1.0, 2014-10-10
 * @version 1.7, 2017-04-04  We change the URL pattern to "/jnode/proxy/image_file.html" and change the stored attribute name of the request to "jnode_param"
 * @author  Jeasu Kim
 */
@WebServlet(urlPatterns = "/jnode/proxy/image_file.html")
public class ImageFileServlet extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method reads the image file from the URL of another domain.
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		// In Firefox, there is no origin in the header, so treat it as a referer.
		if (origin == null)  origin = request.getHeader("referer");

		if (origin == null || origin.indexOf(host) < 0) {
			// Block requests from other domains.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			serviceProxy(request, response);
		}
	}

	/**
	 * This method converts the uploaded client's image file to a Base64 string or reads the image file from the URL of another domain.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		// In Firefox, there is no origin in the header, so treat it as a referer.
		if (origin == null)  origin = request.getHeader("referer");

		if (origin == null || origin.indexOf(host) < 0) {
			// Block requests from other domains.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			if (ServletFileUpload.isMultipartContent(request)) {
				seriveClientImageFile(request, response);
			} else {
				serviceProxy(request, response);
			}
		}
	}

	/**
	 * This method converts the uploaded client's image file to a Base64 string
	 * 
	 * @param  request   Client request object.
	 * @param  response  Server response object.
	 * @throws IOException       When the image file can not be read.
	 * @throws ServletException  When the uploaded image file can not be output as a response.
	 */
	@SuppressWarnings("unchecked")
	private void seriveClientImageFile(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try {
			String encoding     = request.getCharacterEncoding();
			String errorMessage = null;

			Map<String,Object> paramMap = new HashMap<String,Object>();

			// Variables for processing multiple values
			List<String> multiParamList = new ArrayList<String>();
			List<String> multiFileList  = new ArrayList<String>();
			List<String> fileList = new ArrayList<String>();
			ArrayList<String> arrlstParam = null;
			ArrayList<Map<String,Object>> arrlstFile = null;

			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);

			List<FileItem> items = upload.parseRequest(request);

			String fieldName  = null;
			String fieldValue = null;

			for (FileItem item : items) {
				fieldName  = item.getFieldName();

				if (item.isFormField()) {
					// When it is a generic form field
					if (encoding == null)  fieldValue = item.getString();
					else                   fieldValue = item.getString(encoding);

					if (paramMap.containsKey(fieldName)) {
						// Processing for multiple values
						if (paramMap.get(fieldName) instanceof java.lang.String) {
							// First discover that it is a multiple value
							multiParamList.add(fieldName);
							arrlstParam = new ArrayList<String>();
							arrlstParam.add((String)paramMap.get(fieldName));
							arrlstParam.add(fieldValue);
						} else {
							// Already know that there are multiple values
							arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
							arrlstParam.add(fieldValue);
						}

						paramMap.put(fieldName, arrlstParam);
					} else {
						// Processing for Singular Values
						paramMap.put(fieldName, fieldValue);
					}
				} else {
					// When it is a binary file
					String contentType = item.getContentType();

					// Firefox does not recognize webp as an image.
					// if (contentType.equals("application/octet-stream") && item.getName().toLowerCase().endsWith(".webp"))  contentType = "image/webp";

					if (contentType.startsWith("image/")) {
						Map<String,Object> imgFileMap = new HashMap<String,Object>();
						imgFileMap.put("name"       , item.getName());
						imgFileMap.put("contentType", contentType);
						imgFileMap.put("inputStream", item.getInputStream());
						imgFileMap.put("size"       , item.getSize());

						if (paramMap.containsKey(fieldName)) {
							// Processing for multiple values
							if (paramMap.get(fieldName) instanceof java.util.Map) {
								// First discover that it is a multiple value
								multiFileList.add(fieldName);
								arrlstFile = new ArrayList<Map<String,Object>>();
								arrlstFile.add((Map<String,Object>)paramMap.get(fieldName));
								arrlstFile.add(imgFileMap);
							} else {
								// Already know that there are multiple values
								arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
								arrlstFile.add(imgFileMap);
							}

							paramMap.put(fieldName, arrlstFile);
						} else {
							// Processing for Singular file
							paramMap.put(fieldName, imgFileMap);
							fileList.add(fieldName);
						}
					} else {
						errorMessage = "The upload file should be image format.";
						break;
					}
				}
			}

			// Convert multiple values temporarily stored in ArrayList to String []
			for (int i = 0; i < multiParamList.size(); i++) {
				fieldName = (String)multiParamList.get(i);
				arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstParam.toArray(new String[arrlstParam.size()]));
			}

			// Convert multiple values temporarily stored in ArrayList to Map []
			for (int i = 0; i < multiFileList.size(); i++) {
				fieldName = (String)multiFileList.get(i);
				arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstFile.toArray(new Map[arrlstFile.size()]));
			}

			// Convert the file information contained in the InputStream to a Base64 type String.
			// At this time, the size is changed, if there is rewidth or reheight
			int fileSize = fileList.size();
			int[] rewidths  = null;
			int[] reheights = null;

			if (paramMap.containsKey("rewidth")) {
				if (paramMap.get("rewidth") instanceof java.lang.String) {
					rewidths = new int[1];
					rewidths[0] = Integer.parseInt((String)paramMap.get("rewidth"));
				} else {
					String[] rewidthStrings = (String[])paramMap.get("rewidth");

					rewidths = new int[rewidthStrings.length];
					for (int i = 0; i < rewidthStrings.length; i++) {
						rewidths[i] = Integer.parseInt(rewidthStrings[i]);
					}
				}

				int lastRewidth = rewidths[rewidths.length - 1];

				for (int i = rewidths.length; i < fileSize; i++) {
					rewidths[i] = lastRewidth;
				}
			}

			if (paramMap.containsKey("reheight")) {
				if (paramMap.get("reheight") instanceof java.lang.String) {
					reheights = new int[1];
					reheights[0] = Integer.parseInt((String)paramMap.get("reheight"));
				} else {
					String[] reheightStrings = (String[])paramMap.get("reheight");

					reheights = new int[reheightStrings.length];
					for (int i = 0; i < reheightStrings.length; i++) {
						reheights[i] = Integer.parseInt(reheightStrings[i]);
					}
				}

				int lastReheight = reheights[reheights.length - 1];

				for (int i = reheights.length; i < fileSize; i++) {
					reheights[i] = lastReheight;
				}
			}

			for (int i = 0; i < fileSize; i++) {
				fieldName = (String)fileList.get(i);

				Object objFile =paramMap.get(fieldName);

				if (objFile instanceof java.util.Map) {
					Map<String,Object> imgFileMap = (Map<String,Object>)objFile;

					String      contentType = (String)imgFileMap.get("contentType");
					InputStream inputStream = (InputStream)imgFileMap.get("inputStream");
					boolean     resizable   = contentType.toLowerCase().matches("^image/((png)|(jpg)|(jpeg)|(jpe)|(gif))$");

					if (!resizable || ((rewidths == null) && (reheights == null))) {
						// imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(IOUtils.toByteArray(inputStream))));
						imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream))));
					} else {
						BufferedImage bi = ImageIO.read(inputStream);
						int width  = bi.getWidth();
						int height = bi.getHeight();

						if ((rewidths != null) && (rewidths[i] > 0) && (rewidths[i] < width)) {
							height = height * rewidths[i] / width;
							width  = rewidths[i];
						}

						if ((reheights != null) && (reheights[i] > 0) && (reheights[i] < height)) {
							width  = width * reheights[i] / height;
							height = reheights[i];
						}

						BufferedImage bo = new BufferedImage(width, height, bi.getType());
						Graphics2D g2d = bo.createGraphics();
						g2d.drawImage(bi, 0, 0, width, height, null);
						g2d.dispose();

						ByteArrayOutputStream buffer = new ByteArrayOutputStream();
						ImageIO.write(bo, contentType.substring(6), buffer);
						// imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(buffer.toByteArray())));
						imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(buffer.toByteArray())));
					}

					paramMap.put(fieldName, imgFileMap);
				} else {
					Map<String,Object>[] imgFileMaps = (Map<String,Object>[])objFile;

					for (int j = 0; j < imgFileMaps.length; j++) {
						String      contentType = (String)imgFileMaps[j].get("contentType");
						InputStream inputStream = (InputStream)imgFileMaps[j].get("inputStream");
						boolean     resizable   = contentType.toLowerCase().matches("^image/((png)|(jpg)|(jpeg)|(jpe)|(gif))$");

						if (!resizable || ((rewidths == null) && (reheights == null))) {
							// imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(IOUtils.toByteArray(inputStream))));
							imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream))));
						} else {
							BufferedImage bi = ImageIO.read(inputStream);
							int width  = bi.getWidth();
							int height = bi.getHeight();

							if ((rewidths != null) && (rewidths[i] > 0) && (rewidths[i] < width)) {
								height = height * rewidths[i] / width;
								width  = rewidths[i];
							}

							if ((reheights != null) && (reheights[i] > 0) && (reheights[i] < height)) {
								width  = width * reheights[i] / height;
								height = reheights[i];
							}

							BufferedImage bo = new BufferedImage(width, height, bi.getType());
							Graphics2D g2d = bo.createGraphics();
							g2d.drawImage(bi, 0, 0, width, height, null);
							g2d.dispose();

							ByteArrayOutputStream buffer = new ByteArrayOutputStream();
							ImageIO.write(bo, contentType.substring(6), buffer);
							// imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(buffer.toByteArray())));
							imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(buffer.toByteArray())));
						}
					}

					paramMap.put(fieldName, imgFileMaps);
				}
			}

			request.setAttribute("jnode_param", paramMap);

			Object forwardUriObj = paramMap.get("forward_uri");
			String forwardUri = null;
			if (forwardUriObj instanceof String) {
				forwardUri = (String)forwardUriObj;
			} else if (forwardUriObj instanceof String[]) {
				forwardUri = ((String[])forwardUriObj)[0];
			}

			if (forwardUri == null) {
				throw new RuntimeException("forward_uri parameter is required.");
			}

			if (errorMessage != null) {
				request.setAttribute("error_message", errorMessage);
			}

			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(forwardUri);
			dispatcher.forward(request, response);
		} catch (FileUploadException e) {
			throw new RuntimeException("Cannot load the local file.", e);
		}
	}
	

	/**
	 * This method reads the image file from the URL of another domain.
	 * 
	 * @param  request   Client request object.
	 * @param  response  Server response object.
	 * @throws IOException  When the image file can not be read.
	 */
	private void serviceProxy(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String targetUrl      = request.getParameter("url");
		String contenttype    = request.getParameter("contenttype");
		String accept         = request.getParameter("accept");
		String rewidthString  = request.getParameter("rewidth");
		String reheightString = request.getParameter("reheight");
		String reqEncoding    = request.getCharacterEncoding();
		String paramValue     = getParamValue(request);

		if (targetUrl   == null)  throw new RuntimeException("The URL address to load is empty");
		if (reqEncoding == null)  reqEncoding = "UTF-8";
		if (contenttype == null)  contenttype = "application/x-www-form-urlencoded;charset=" + reqEncoding;
		
		int rewidth  = -1;
		int reheight = -1;

		if (rewidthString  != null)  rewidth  = Integer.parseInt(rewidthString);
		if (reheightString != null)  reheight = Integer.parseInt(reheightString);

		URL url = new URL(targetUrl);

		HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
		urlConn.setRequestMethod(request.getMethod());
		urlConn.setDoOutput(true);
		urlConn.setDoInput(true);
		urlConn.setUseCaches(false);
		// urlConn.setFollowRedirects(false);

		urlConn.setRequestProperty("Content-Type", contenttype);

		if (accept != null)  urlConn.setRequestProperty("Accept", accept);

		if (paramValue != null) {
			DataOutputStream  output = new DataOutputStream(urlConn.getOutputStream());
			output.writeBytes(paramValue);
		}

		String      urlValue    = null;
		String      contentType = urlConn.getContentType();
		InputStream inputStream = urlConn.getInputStream();
		boolean     resizable   = contentType.toLowerCase().matches("^image/((png)|(jpg)|(jpeg)|(jpe)|(gif))$");

		if (!resizable || ((rewidth < 0) && (reheight < 0))) {
			// urlValue = "data:" + contentType + ";base64," + new String(Base64.encodeBase64(IOUtils.toByteArray(inputStream)));
			urlValue = "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream)));
		} else {
			BufferedImage bi = ImageIO.read(inputStream);
			int width  = bi.getWidth();
			int height = bi.getHeight();

			if ((rewidth > 0) && (rewidth < width)) {
				height = height * rewidth / width;
				width  = rewidth;
			}

			if ((reheight > 0) && (reheight < height)) {
				width  = width * reheight / height;
				height = reheight;
			}

			BufferedImage bo = new BufferedImage(width, height, bi.getType());
			Graphics2D g2d = bo.createGraphics();
			g2d.drawImage(bi, 0, 0, width, height, null);
			g2d.dispose();

			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			ImageIO.write(bo, contentType.substring(6), buffer);
			// urlValue = "data:" + contentType + ";base64," + new String(Base64.encodeBase64(buffer.toByteArray()));
			urlValue = "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(buffer.toByteArray()));
		}

		response.setContentType("text/plain; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(urlValue);
	}

	/**
	 * The parameters needed to read the image file from the server URL are retrieved as a string.
	 * 
	 * In the parameters, url, contenttype, and accept are values used internally by the Servlet to read the image file from the server URL.
	 * If you need parameters with the same name, you can send them to the second of the array.
	 * 
	 * @param  request   Client request object.
	 * @return The string whose parameters have changed.
	 * @throws UnsupportedEncodingException  When the encoding is used with non-declared, changing parameters to characters
	 */
	private String getParamValue(HttpServletRequest request) throws UnsupportedEncodingException {
		Enumeration<String> enumParamName = request.getParameterNames();
		String encoding = request.getCharacterEncoding();

		if (encoding == null)  encoding = "UTF-8";

		StringBuffer parameterBuffer = new StringBuffer();

		while (enumParamName.hasMoreElements()) {
			String paramName = enumParamName.nextElement();
			String[] values = request.getParameterValues(paramName);
			int startIndex = 0;

			if (paramName.equals("url") || paramName.equals("contenttype") || paramName.equals("accept")) {
				startIndex = 1;
			}

			for (int i = startIndex; i < values.length; i++) {
				parameterBuffer.append("&").append(paramName).append("=").append(URLEncoder.encode(values[i], encoding));
			}
		}

		String paramValue = parameterBuffer.toString();

		if (paramValue.equals("")) {
			return null;
		} else {
			return paramValue.substring(1);
		}
	}
}
