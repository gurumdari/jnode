/*
 * @(#)TextFileServlet.java  1.7, 2017-04-04
 */
package com.jnodeframework.resolver;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

/**
 * Servlet that uploads and reads text file from client, or reads text file from URL of other domain.
 * 
 * It is called with the URL pattern "/jnode/proxy/text_file.html" registered in WebServlet annotation.
 * Up to version 1.6 of the Jnode Framework, WebServlet annotation was registered with the URL pattern "/servlet/com.jnodeframework.resolver.TextFileServlet".
 * However, since version 1.7 of the Jnode Framework, we have changed the URL pattern to "/jnode/proxy/text_file.html"
 * to eliminate the dependency of the back-end environment when supporting PHP interpreter.
 * 
 * TextFileServlet reads an text file in two ways.
 * If the encoding type is requested by multipart/form-data, the text file uploaded from the client is read and output.
 * When the encoding type is requested by application/x-www-form-urlencoded,
 * and the text file corresponding to the url is read when the URL address to read the text file is passed as the url parameter.
 * 
 * 
 * [Text file upload processing]
 * 
 * If the encoding type is passed to multipart/form-data, the text file is assumed to have been uploaded from the client,
 * and forwarded to the page corresponding to the parameter forward_uri containing the parameter information with the name jnode_param in the attribute of the request.
 * The parameters used internally are as follows. If parameters with the same name as those used internally are needed, you can store them in the next values of the array.
 * 
 * <UL>
 *   <LI><CODE>forward_uri</CODE> - The URI address to be forwarded after putting the parameters passed in multipart/form-data type as jnode_param.</LI>
 *   <LI><CODE>encoding</CODE> - The encoding type to read uploaded text file.</LI>
 * </UL>
 * 
 * The index of the encoding array corresponding to the field name index of the uploaded text file is used as the encoding type to read the contents.
 * If the number of encoding arrays is less than the number of field names in the uploaded text file, the value of the last array is used as the remaining encoding type.
 * If no encoding value is used, UTF-8 is used by default.
 * However, even if there are multiple field names in the same uploaded text file, the encoding will only be processed in the single array index.
 * 
 * The parameters are stored in jnode_param with the following rules. Up to Jnode Framework version 1.6,
 * the name of multipart_param, but since version 1.7 PHP Interpeter support was unified as jnode_param.
 * 
 * <UL>
 *   <LI>Single general parameter - In Map&lt;String, String&gt; format, field name contains field value.</LI>
 *   <LI>Multiple general parameters - In Map&lt;String, String[]&gt; format, field name contains an array of field values.</LI>
 *   <LI>Single upload file parameter - In Map&lt;String, Map&lt;String, Object&gt;&gt; format, field name contains text file information.</LI>
 *   <LI>Multiple upload file parameter - In Map&lt;String, Map&lt;String, Object&gt;[]&gt; format, field name contains an array of text file information.</LI>
 * </UL>
 * 
 * The information of the uploaded text file is put in the following key.
 * 
 * <UL>
 *   <LI><CODE>name</CODE> - The name of the uploaded text file.</LI>
 *   <LI><CODE>value</CODE> - The string that reads the contents of the uploaded text file.</LI>
 *   <LI><CODE>inputStream</CODE> - The InputStream value of the content of the uploaded text file. If the value is garbled, you can parse it directly as a string via InputStream.</LI>
 *   <LI><CODE>contentType</CODE> - The content type of the uploaded file.</LI>
 *   <LI><CODE>size</CODE> - The long value of the uploaded file's size.</LI>
 * </UL>
 * 
 * 
 * [Proxy processing of text file of URL like local domain]
 * 
 * If the encoding type is passed to application/x-www-form-urlencoded, it is assumed that the text file of the URL wants to be read,
 * and the text corresponding to the url parameter is read the content and output.
 * Internally used parameters are as follows, and other values are used as parameters to call the URL corresponding to the url parameter.
 * If a parameter with the same name as an internally used parameter is needed, it is stored in the next value of the array.
 * 
 * <UL>
 *   <LI><CODE>url</CODE> - URL address from which to read the text file.</LI>
 *   <LI><CODE>encoding</CODE> - The encoding type to read the text file of the URL address.</LI>
 *   <LI><CODE>contenttype</CODE> - The content type of the request to read the text file of the URL address.</LI>
 *   <LI><CODE>accept</CODE> - The accept type of the response to read the text file of the URL address.</LI>
 * </UL>
 * 
 * If there is no encoding, it is treated as UTF-8. If there is no contenttype, it is treated as application/x-www-form-urlencoded;charset=${request_encoding}.
 * The ${request_encoding} is the value set in the CharacterEncoding of the request, otherwise it is treated as UTF-8. If it does not accept, it is ignored.
 * 
 * The TextFileServlet internally prints a "Not allowed from the cross domain" message when exporting to a 403 status code when requested from another domain.
 * Therefore, similar to the processing inside TextFileServlet, if the page corresponding to url is processed to reject another domain request, the page can not be read.
 * 
 * @version 1.0, 2014-10-10
 * @version 1.7, 2017-04-04  We change the URL pattern to "/jnode/proxy/text_file.html" and change the stored attribute name of the request to "jnode_param"
 * @author  Jeasu Kim
 */
@WebServlet(urlPatterns = "/jnode/proxy/text_file.html")
public class TextFileServlet extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method reads the text file from the URL of another domain.
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		// In Firefox, there is no origin in the header, so treat it as a referer.
		if (origin == null)  origin = request.getHeader("referer");

		if (origin == null || origin.indexOf(host) < 0) {
			// Block requests from other domains.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			serviceProxy(request, response);
		}
	}

	/**
	 * This method reads the text file of the uploaded from client or from the URL of another domain.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		// In Firefox, there is no origin in the header, so treat it as a referer.
		if (origin == null)  origin = request.getHeader("referer");

		if (origin == null || origin.indexOf(host) < 0) {
			// Block requests from other domains.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			if (ServletFileUpload.isMultipartContent(request)) {
				seriveClientTextFile(request, response);
			} else {
				serviceProxy(request, response);
			}
		}
	}

	/**
	 * This method reads the text file of the uploaded from client.
	 * 
	 * @param  request   Client request object.
	 * @param  response  Server response object.
	 * @throws IOException       When the text file can not be read.
	 * @throws ServletException  When the uploaded text file can not be output as a response.
	 */
	@SuppressWarnings("unchecked")
	private void seriveClientTextFile(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try {
			String encoding = request.getCharacterEncoding();

			Map<String,Object> paramMap = new HashMap<String,Object>();

			// Variables for processing multiple values
			List<String> multiParamList = new ArrayList<String>();
			List<String> multiFileList  = new ArrayList<String>();
			List<String> fileList = new ArrayList<String>();
			ArrayList<String> arrlstParam = null;
			ArrayList<Map<String,Object>> arrlstFile = null;

			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);

			List<FileItem> items = upload.parseRequest(request);

			String fieldName  = null;
			String fieldValue = null;

			for (FileItem item : items) {
				fieldName  = item.getFieldName();

				if (item.isFormField()) {
					// When it is a generic form field
					if (encoding == null)  fieldValue = item.getString();
					else                   fieldValue = item.getString(encoding);

					if (paramMap.containsKey(fieldName)) {
						// Processing for multiple values
						if (paramMap.get(fieldName) instanceof java.lang.String) {
							// First discover that it is a multiple value
							multiParamList.add(fieldName);
							arrlstParam = new ArrayList<String>();
							arrlstParam.add((String)paramMap.get(fieldName));
							arrlstParam.add(fieldValue);
						} else {
							// Already know that there are multiple values
							arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
							arrlstParam.add(fieldValue);
						}

						paramMap.put(fieldName, arrlstParam);
					} else {
						// Processing for Singular Values
						paramMap.put(fieldName, fieldValue);
					}
				} else {
					// When it is a binary file
					Map<String,Object> textFileMap = new HashMap<String,Object>();
					textFileMap.put("name"       , item.getName());
					textFileMap.put("contentType", item.getContentType());
					textFileMap.put("inputStream", item.getInputStream());
					textFileMap.put("size"       , item.getSize());

					if (paramMap.containsKey(fieldName)) {
						// Processing for multiple values
						if (paramMap.get(fieldName) instanceof java.util.Map) {
							// First discover that it is a multiple value
							multiFileList.add(fieldName);
							arrlstFile = new ArrayList<Map<String,Object>>();
							arrlstFile.add((Map<String,Object>)paramMap.get(fieldName));
							arrlstFile.add(textFileMap);
						} else {
							// Already know that there are multiple values
							arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
							arrlstFile.add(textFileMap);
						}

						paramMap.put(fieldName, arrlstFile);
					} else {
						// Processing for Singular file
						paramMap.put(fieldName, textFileMap);
						fileList.add(fieldName);
					}
				}
			}

			// Convert multiple values temporarily stored in ArrayList to String []
			for (int i = 0; i < multiParamList.size(); i++) {
				fieldName = (String)multiParamList.get(i);
				arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstParam.toArray(new String[arrlstParam.size()]));
			}

			// Convert multiple values temporarily stored in ArrayList to Map []
			for (int i = 0; i < multiFileList.size(); i++) {
				fieldName = (String)multiFileList.get(i);
				arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstFile.toArray(new Map[arrlstFile.size()]));
			}

			// Convert the file information contained in the InputStream to a String.
			int fileSize = fileList.size();
			if (encoding == null)  encoding = "UTF-8";
			String[] fileEncodings = null;

			if (paramMap.containsKey("encoding")) {
				if (paramMap.get("encoding") instanceof java.lang.String) {
					fileEncodings = new String[1];
					fileEncodings[0] = (String)paramMap.get("encoding");
				} else {
					fileEncodings = (String[])paramMap.get("encoding");
				}

				String lastFileEncoding = fileEncodings[fileEncodings.length - 1];

				for (int i = fileEncodings.length; i < fileSize; i++) {
					fileEncodings[i] = lastFileEncoding;
				}
			} else {
				fileEncodings = new String[fileSize];
				for (int i = 0; i < fileSize; i++) {
					fileEncodings[i] = encoding;
				}
			}

			for (int i = 0; i < fileSize; i++) {
				fieldName = (String)fileList.get(i);

				Object objFile =paramMap.get(fieldName);

				if (objFile instanceof java.util.Map) {
					Map<String,Object> textFileMap = (Map<String,Object>)objFile;

					String fileValue = IOUtils.toString((InputStream)textFileMap.get("inputStream"), fileEncodings[i]);
					if (fileValue.startsWith("\ufeff"))  fileValue = fileValue.substring(1);  // Remove characters representing UTF-8 + BOM encoding type
					textFileMap.put("value", fileValue);

					paramMap.put(fieldName, textFileMap);
				} else {
					Map<String,Object>[] textFileMaps = (Map<String,Object>[])objFile;

					for (int j = 0; j < textFileMaps.length; j++) {
						String fileValue = IOUtils.toString((InputStream)textFileMaps[j].get("inputStream"), fileEncodings[i]);
						if (fileValue.startsWith("\ufeff"))  fileValue = fileValue.substring(1);  // Remove characters representing UTF-8 + BOM encoding type
						textFileMaps[j].put("value", fileValue);
					}

					paramMap.put(fieldName, textFileMaps);
				}
			}

			request.setAttribute("jnode_param", paramMap);

			Object forwardUriObj = paramMap.get("forward_uri");
			String forwardUri = null;
			if (forwardUriObj instanceof String) {
				forwardUri = (String)forwardUriObj;
			} else if (forwardUriObj instanceof String[]) {
				forwardUri = ((String[])forwardUriObj)[0];
			}

			if (forwardUri == null) {
				throw new RuntimeException("forward_uri parameter is required.");
			}

			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(forwardUri);
			dispatcher.forward(request, response);
		} catch (FileUploadException e) {
			throw new RuntimeException("Cannot load the local file.", e);
		}
	}
	

	/**
	 * This method reads the text file from the URL of another domain.
	 * 
	 * @param  request   Client request object.
	 * @param  response  Server response object.
	 * @throws IOException  When the text file can not be read.
	 */
	private void serviceProxy(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String targetUrl   = request.getParameter("url");
		String encoding    = request.getParameter("encoding");
		String contenttype = request.getParameter("contenttype");
		String accept      = request.getParameter("accept");
		String reqEncoding = request.getCharacterEncoding();
		String paramValue  = getParamValue(request);

		if (targetUrl   == null)  throw new RuntimeException("The URL address to load is empty");
		if (encoding    == null)  encoding    = "UTF-8";
		if (reqEncoding == null)  reqEncoding = "UTF-8";
		if (contenttype == null)  contenttype = "application/x-www-form-urlencoded;charset=" + reqEncoding;

		URL url = new URL(targetUrl);

		HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
		urlConn.setRequestMethod(request.getMethod());
		urlConn.setDoOutput(true);
		urlConn.setDoInput(true);
		urlConn.setUseCaches(false);
		// urlConn.setFollowRedirects(false);

		urlConn.setRequestProperty("Content-Type", contenttype);

		if (accept != null)  urlConn.setRequestProperty("Accept", accept);

		if (paramValue != null) {
			DataOutputStream  output = new DataOutputStream(urlConn.getOutputStream());
			output.writeBytes(paramValue);
		}

		String urlValue = IOUtils.toString(urlConn.getInputStream(), encoding);
		if (urlValue.startsWith("\ufeff"))  urlValue = urlValue.substring(1);  // Remove characters representing UTF-8 + BOM encoding type

		response.setContentType("text/plain; charset=" + encoding);
		PrintWriter out = response.getWriter();
		out.print(urlValue);
	}

	/**
	 * The parameters needed to read the text file from the server URL are retrieved as a string.
	 * 
	 * In the parameters, url, encoding, contenttype, and accept are values used internally by the Servlet to read the text file from the server URL.
	 * If you need parameters with the same name, you can send them to the second of the array.
	 * 
	 * @param  request   Client request object.
	 * @return The string whose parameters have changed.
	 * @throws UnsupportedEncodingException  When the encoding is used with non-declared, changing parameters to characters
	 */
	private String getParamValue(HttpServletRequest request) throws UnsupportedEncodingException {
		Enumeration<String> enumParamName = request.getParameterNames();
		String encoding = request.getCharacterEncoding();

		if (encoding == null)  encoding = "UTF-8";

		StringBuffer parameterBuffer = new StringBuffer();

		while (enumParamName.hasMoreElements()) {
			String paramName = enumParamName.nextElement();
			String[] values = request.getParameterValues(paramName);
			int startIndex = 0;

			if (paramName.equals("url") || paramName.equals("encoding") || paramName.equals("contenttype") || paramName.equals("accept")) {
				startIndex = 1;
			}

			for (int i = startIndex; i < values.length; i++) {
				parameterBuffer.append("&").append(URLEncoder.encode(paramName, encoding)).append("=").append(URLEncoder.encode(values[i], encoding));
			}
		}

		String paramValue = parameterBuffer.toString();

		if (paramValue.equals("")) {
			return null;
		} else {
			return paramValue.substring(1);
		}
	}
}
