/*
 * @(#)JsonResolver.java  1.7, 2017-04-04
 */
package com.jnodeframework.resolver;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.jnodeframework.util.RequestUtil;

/**
 * Class that resolves response result to JSON notation string.
 * 
 * @version 1.0, 2014-10-10
 * @version 1.6, 2016-02-02  Providing converting function of Java Map Object as JSON
 * @version 1.7, 2017-04-04  The getJsonParam method returns with the Map&lt;String, ?&gt; format since 1.7.
 * @version 1.8, 2017-05-10  The resolve method can be passed Java List Object as parameter.
 * @author  Jeasu Kim
 */
public class JsonResolver {
	private HttpServletResponse response    = null;
	private RequestUtil         requestUtil = null;

	/**
	 * JsonResolver constructor.
	 * 
	 * @param request   Client request object.
	 * @param response  Server response object.
	 */
	public JsonResolver(HttpServletRequest request, HttpServletResponse response) {
		requestUtil = new RequestUtil(request);

		this.response = response;
	}

	/**
	 * This method converts a JSON notation string containing an array into a List object.
	 * 
	 * @param   listJson  he JSON notation string containing the array.
	 * @param   type      Type to reflect as a Java object.
	 * @return  A List object that converts the array notation string.
	 * @deprecated  As of Version 1.7 of the Jnode Framework.
	 */
	public List<?> getJsonList(String listJson, Type type) {
		return requestUtil.getJsonList(listJson, type);
	}

	/**
	 * This method converts the parameters of the JSON notation string contained in the HttpServletRequest to a Map object.
	 * 
	 * Up to version 1.6 of the Jnode Framework, only Map&lt;String, String&gt; format could be converted.
	 * However, since version 1.7 of the Jnode Framework, the Map&lt;String, ?&gt; format can be converted.
	 * 
	 * @return A Map object that is converted from the parameters of the JSON notation string requested by the Client.
	 */
	public Map<String, ?> getJsonParam() {
		return requestUtil.getJsonParam();
	}

	/**
	 * This method converts the parameters of the JSON notation string contained in the HttpServletRequest to a Map object.
	 * 
	 * @param  stringOnly  Whether the Map object only contains a string as a value.
	 * @return A Map object that is converted from the parameters of the JSON notation string requested by the Client.
	 * @since  1.7
	 */
	public Map<String, ?> getJsonParam(boolean stringOnly) {
		return requestUtil.getJsonParam(stringOnly);
	}

	/**
	 * This method retrieves the Page ID for the template file requested by front-end for use as page.
	 * 
	 * Page ID is the same as URI excluding the context path and the extension.
	 * 
	 * @return Page ID.
	 */
	public String getPageId() {
		return requestUtil.getPageId();
	}

	/**
	 * This method retrieves the Page ID for template file corresponding to requestURI including context path.
	 * 
	 * This method retrieves the Page ID by excluding the context path and its extension in requestURI.
	 * If requestURI does not have an extension, it is assumed to be a directory, and the index file in that directory is used.
	 * 
	 * @param  requestURI  A URI that contains the context path.
	 * @return Page ID.
	 */
	public String getPageId(String requestURI) {
		return requestUtil.getPageId(requestURI);
	}

	/**
	 * This method retrieves the page ID that is processed when the template file requested by the front-end for use as a page is in not state code 200.
	 * 
	 * @param  statusCode  Status code.
	 * @return Page ID based on status code
	 */
	public String getPageId(int statusCode) {
		return requestUtil.getPageId(statusCode);
	}

	/**
	 * This method retrieves the status code of page.
	 * 
	 * @return The status code of page.
	 */
	public int getPageStatusCode() {
		return requestUtil.getPageStatusCode();
	}

	/**
	 * This method parses the requestURI including the context path to get the page status code.
	 * 
	 * If you do not use error handling in the Jnode Framework, you can get an incorrect value.
	 * 
	 * @param  requestURI  A URI that contains the context path.
	 * @return The status code of page..
	 */
	public int getPageStatusCode(String requestURI) {
		return requestUtil.getPageStatusCode(requestURI);
	}

	/**
	 * This method resolves a empty value by converting it to JSON notation string.
	 * 
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 * @since  1.8
	 */
	public void resolve() throws IOException {
		resolve("{}", null);
	}

	/**
	 * This method resolves a Java List object by converting it to JSON notation string with UTF-8 character set.
	 * 
	 * @param  datalist     A Java List object that converts to a JSON notation string and responds with the response.
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 * @since  1.8
	 */
	public void resolve(List<?> dataList) throws IOException {
		resolve(dataList, null);
	}

	/**
	 * This method resolves a Java List object by converting it to JSON notation string.
	 * 
	 * @param  datalist     A Java List object that converts to a JSON notation string and responds with the response.
	 * @param  encoding     Character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 * @since  1.8
	 */
	public void resolve(List<?> dataList, String encoding) throws IOException {
		resolve(new Gson().toJson(dataList), encoding);
	}

	/**
	 * This method resolves a Java Map object by converting it to JSON notation string with UTF-8 character set.
	 * 
	 * @param  datamap      A Java Map object that converts to a JSON notation string and responds with the response.
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 * @since  1.6
	 */
	public void resolve(Map<String, ?> datamap) throws IOException {
		resolve(datamap, null);
	}

	/**
	 * This method resolves a Java Map object by converting it to JSON notation string.
	 * 
	 * @param  datamap      A Java Map object that converts to a JSON notation string and responds with the response.
	 * @param  encoding     Character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 * @since  1.6
	 */
	public void resolve(Map<String, ?> datamap, String encoding) throws IOException {
		resolve(new Gson().toJson(datamap), encoding);
	}

	/**
	 * This method resolves JSON notation string results with UTF-8 character set.
	 * 
	 * @param  dataset      The JSON notation string to respond with.
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 */
	public void resolve(String dataset) throws IOException {
		resolve(dataset, null);
	}

	/**
	 * This method resolves JSON notation string results.
	 * 
	 * @param  dataset      The JSON notation string to respond with.
	 * @param  encoding     Character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When this method can not output the JSON notation string to be passed to the HttpServletResponse object.
	 */
	public void resolve(String dataset, String encoding) throws IOException {
		if (encoding == null)  encoding = "UTF-8";

		response.setContentType("application/json; charset=" + encoding);
		PrintWriter out = response.getWriter();
		out.print(dataset);
	}
}