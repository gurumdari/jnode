/*
 * @(#)JnodeFunction.java  1.0, 2014-10-10
 */
package com.jnodeframework.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import com.google.gson.Gson;

//import org.apache.commons.codec.binary.Base64;

/**
 * Utility Class related function of +JEE Jnode framework additional module.
 *
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class JnodeFunction {

	/**
	 * This method decodes Base64-encoded string with UTF-8 character set.
	 * 
	 * @param  value  The string encoded with Base64.
	 * @return Decoded string.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String decodeBase64(String value) throws UnsupportedEncodingException {
		// return new String(Base64.decodeBase64(value.getBytes("UTF-8")));
		return new String(Base64.getDecoder().decode(value), "UTF-8");
	}

	/**
	 * This method decodes a string encoded in URL notation format with <CODE>charset</CODE> character set.
	 * 
	 * @param  value    String encoded in URL notation format.
	 * @param  charset  The character set.
	 * @return Decoded string.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 * @since  Jnode Framework 1.6
	 */
	public static String decodeURL(String value, String charset) throws UnsupportedEncodingException {
		return URLDecoder.decode(value, charset);
	}

	/**
	 * This method disables Friendly HTTP error messages output on Edge or Internet Explorer.
	 * 
	 * <P>
	 * Edge or Internet Explorer provides a built-in function that, when an error occurs,
	 * ignores the page output from the WAS Server and outputs a friendly error message to the web browser itself.
	 * When an error occurs with less than than 512 bytes response,
	 * the web browser itself has a function of ignoring the output from the WAS server and outputting the contents of the message itself.
	 * 
	 * <P>
	 * You can disable the Friendly HTTP error messages output by adding an additional dummy content that is larger than 512 bytes,
	 * or by using the <CODE>200</CODE> status code to prevent the web browser from recognizing the error.
	 * This function provides a way to drop to a <CODE>200</CODE> status code.
	 * 
	 * <P>
	 * You can set the <CODE>exceptExts</CODE> parameter to have an extension that disables Friendly HTTP error messages output with a comma(<CODE>,</CODE>) as a separator.
	 * 
	 * @param pageContext  The context object of the JSP page.
	 * @param exceptExts   Extensions to disable the output disable Friendly HTTP error messages.
	 */
	public static void disableFriendlyErrorMessage(PageContext pageContext, String exceptExts) {
		HttpServletRequest  request  = (HttpServletRequest)pageContext.getRequest();
		HttpServletResponse response = (HttpServletResponse)pageContext.getResponse();

		disableFriendlyErrorMessage2(request, response, exceptExts);
	}

	/**
	 * This method disables Friendly HTTP error messages output on Edge or Internet Explorer.
	 * 
	 * <P>
	 * Edge or Internet Explorer provides a built-in function that, when an error occurs,
	 * ignores the page output from the WAS Server and outputs a friendly error message to the web browser itself.
	 * When an error occurs with less than than 512 bytes response,
	 * the web browser itself has a function of ignoring the output from the WAS server and outputting the contents of the message itself.
	 * 
	 * <P>
	 * You can disable the Friendly HTTP error messages output by adding an additional dummy content that is larger than 512 bytes,
	 * or by using the <CODE>200</CODE> status code to prevent the web browser from recognizing the error.
	 * This function provides a way to drop to a <CODE>200</CODE> status code.
	 * 
	 * <P>
	 * You can set the <CODE>exceptExts</CODE> parameter to have an extension that disables Friendly HTTP error messages output with a comma(<CODE>,</CODE>) as a separator.
	 * 
	 * @param request     Client request object.
	 * @param response    Server response object.
	 * @param exceptExts  Extensions to disable the output disable Friendly HTTP error messages.
	 */
	public static void disableFriendlyErrorMessage2(HttpServletRequest request, HttpServletResponse response, String exceptExts) {
		if (request.getParameter("template") == null || request.getParameter("requireType") == null || request.getParameter("nodeType") == null) {
			String errorRequestUri = (String)request.getAttribute("javax.servlet.error.request_uri");
			boolean hasExceptExt = false;

			if (!(errorRequestUri == null || exceptExts == null)) {
				String[] separatedExceptExts = exceptExts.split(",");

				for (String exceptExt : separatedExceptExts) {
					if (errorRequestUri.toLowerCase().endsWith("." + exceptExt.trim().toLowerCase())) {
						hasExceptExt = true;
						break;
					}
				}
			}

			if (!hasExceptExt) {
				response.setStatus(200);
			}
		}
	}

	/**
	 * This method encodes a string into Base64 string with UTF-8 character set.
	 * 
	 * @param  value  The string to be encoded as Base64.
	 * @return Base64-encoded string with UTF-8 character set.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String encodeBase64(String value) throws UnsupportedEncodingException {
		// return new String(Base64.encodeBase64(value.getBytes("UTF-8")));
		return new String(Base64.getEncoder().encodeToString(value.getBytes("UTF-8")));
	}

	/**
	 * This method encodes the session information string of JSON notation format into Base64 string with UTF-8 character set.
	 * 
	 * <P>
	 * It is encoded in Base64, but session information can be verified in the front-end environment. Use is not recommended.
	 * 
	 * @param  pageContext  The context object of the JSP page.
	 * @return The session information string of Base64-encoded JSON notation format with UTF-8 character set.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String encodeBase64Session(PageContext pageContext) throws UnsupportedEncodingException {
		HttpSession session = ((HttpServletRequest)(pageContext.getRequest())).getSession();
		return encodeBase64Session2(session);
	}

	/**
	 * This method encodes the session information string of JSON notation format into Base64 string with UTF-8 character set.
	 * 
	 * <P>
	 * It is encoded in Base64, but session information can be verified in the front-end environment. Use is not recommended.
	 * 
	 * @param  session  HTTP Session ojbect.
	 * @return The session information string of Base64-encoded JSON notation format with UTF-8 character set.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String encodeBase64Session2(HttpSession session) throws UnsupportedEncodingException {
		Enumeration<String> attributeNames = session.getAttributeNames();

		Map<String, Object> sessionMap = new HashMap<String, Object>();

		while (attributeNames.hasMoreElements()) {
			String attributeName = attributeNames.nextElement();
			sessionMap.put(attributeName, session.getAttribute(attributeName));
		}

		return encodeBase64(new Gson().toJson(sessionMap));
	}

	/**
	 * This method encodes the string in URL notation format with <CODE>charset</CODE> character set.
	 * 
	 * @param  value    The string to be encoded in URL notation format.
	 * @param  charset  The character set.
	 * @return URL notation format string.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 * @since  Jnode Framework 1.6
	 */
	public static String encodeURL(String value, String charset) throws UnsupportedEncodingException {
		return URLEncoder.encode(value, charset);
	}

	/**
	 * This function handles HTML escape to display target contents at body of HTML tag.
	 * 
	 * Unlike <CODE>escapeXML</CODE> method, This mehtod escapes white space.
	 * Tab character (<CODE>\t</CODE>) is converted into four spaces,
	 * and new line is converted into &lt;BR&gt; tag.
	 * 
	 * @param  value  String to escape the HTML characters.
	 * @return The string escaped the HTML characters.
	 */
	public static String escapeHTML(String value) {
		return escapeHTMLDetail(value, 4, "br");
	}

	/**
	 * This function handles HTML escape to display target contents at body of HTML tag.
	 * 
	 * You can set number of spaces for tab character,\t, at tabindent, and the default number is 4.
	 * New line is converted into &lt;BR&gt; tag.
	 * 
	 * @param  value      The string to escape the HTML characters.
	 * @param  tabindent  The number of spaces to convert Tab character (<CODE>\t</CODE>).
	 * @return The string escaped the HTML characters.
	 * @deprecated  As of Version 1.8 of the Jnode Framework.
	 */
	public static String escapeHTMLConsideredTab(String value, int tabindent) {
		return escapeHTMLDetail(value, tabindent, "br");
	}

	/**
	 * This function handles HTML escape to display target contents at body of HTML tag.
	 * 
	 * You can set number of spaces for tab character,\t, at tabindent, and the default number is 4.
	 * 
	 * If newlineTag is set to "br" or "BR", new line is converted into &lt;BR&gt; tag.
	 * If newlineTag is set to "div" or "DIV", new line is converted into the &lt;DIV&gt; tag.
	 * At this time, if the uppercase "BR" or "DIV" is set, a new line character (\n) is appended to the new line tag.
	 * the default value is "br".
	 * 
	 * @param  value       The string to escape the HTML characters.
	 * @param  tabindent   The number of spaces to convert Tab character (<CODE>\t</CODE>).
	 * @param  newlineTag  HTML element tag to use for processing the new line (<B>"br"</B> | "BR" | "div" | "DIV").
	 * @return The string escaped the HTML characters.
	 * @since  1.8
	 */
	public static String escapeHTMLDetail(String value, int tabindent, String newlineTag) {
		if (value == null)  return null;

		String replacedTab = "";

		for (int i = 0; i < tabindent; i++) {
			replacedTab += " ";
		}

		value = escapeXML(value).replaceAll("\t", replacedTab).replaceAll("(?m)^ ", "&nbsp;").replaceAll("(?m) $", "&nbsp;").replaceAll("  ", " &nbsp;").replaceAll("\r\n", "\n");

		if (value.indexOf("\n") == -1) {
			return value;
		} else {
			if (newlineTag == null)  newlineTag = "br";

			if (newlineTag.equalsIgnoreCase("div")) {
				value = value.replaceAll("\n\n"   , "\n<BR>\n");
				value = value.replaceAll("\n\n"   , "\n<BR>\n");
				value = value.replaceAll("(?m)^\n", "<BR>\n"  );
				value = value.replaceAll("(?m)\n$", "\n<BR>"  );

				if (newlineTag.equals("DIV")) {
					return "<DIV>" + value.replaceAll("\n", "</DIV>\n<DIV>") + "</DIV>";
				} else {
					return "<DIV>" + value.replaceAll("\n", "</DIV><DIV>") + "</DIV>";
				}
			} else {
				if (newlineTag.equals("BR")) {
					return value.replaceAll("\n", "<BR>\n");
				} else {
					return value.replaceAll("\n", "<BR>");
				}
			}
		}
	}

	/**
	 * This method escapes characters for using in JavaScript string.
	 * 
	 * @param  value  String to escape JavaScript characters.
	 * @return The string escaped for JavaScript characters.
	 * @since  Jnode Framework 1.6
	 */
	public static String escapeJS(String value) {
		if (value == null)  return null;

		return value.replaceAll("\\\\", "\\\\\\\\").replaceAll("\\\'", "\\\\\\\'").replaceAll("\\\"", "\\\\\\\"").replaceAll("\\\r", "\\\\\\r").replaceAll("\\\f", "\\\\\\f").replaceAll("\\\t", "\\\\\\t").replaceAll("\\\n", "\\\\\\n").replaceAll("\\\b", "\\\\\\b").replaceAll("<", "\\\\\\u003c").replaceAll(">", "\\\\\\u003e");
	}

	/**
	 * This method escapes the XML characters to output the value of the <CODE>INPUT</CODE> tag (including the <CODE>TEXTAREA</CODE> tag) or the attribute value of the DOM
	 * 
	 * @param  value  The string to escape the XML characters.
	 * @return The string escaped the XML characters.
	 */
	public static String escapeXML(String value) {
		if (value == null)  return null;

		return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
	}
}