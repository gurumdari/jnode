<?php
$domain_dirs = [__DIR__, "..", "..", "..", ".."];
$jnode_files = ["protected_cgi", "lib", "Jnode.Framework.php"];
$jnode_framework_file = join(DIRECTORY_SEPARATOR, array_merge($domain_dirs, $jnode_files));

if (file_exists($jnode_framework_file)) {
	require_once $jnode_framework_file;
} else {
	# If protected_cgi can not be separated from public_html, it is considered to be located in public_html
	array_pop($domain_dirs);
	$jnode_framework_file = join(DIRECTORY_SEPARATOR, array_merge($domain_dirs, $jnode_files));

	if (file_exists($jnode_framework_file)) {
		require_once $jnode_framework_file;
	} else {
		http_response_code(500);
		echo "Jnode framework structure error";
		exit;
	}
}

if (__FILE__ == $_SERVER['DOCUMENT_ROOT'].$_SERVER["REQUEST_URI"]) {
	$jnode = new \Gurumdari\Jnode();
	$jnode->checkHTML5();
	$jnode->sendError(404);
}