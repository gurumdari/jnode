/*
 * @(#)RequestUtil.java  1.7, 2017-04-04
 */
package com.jnodeframework.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;

/**
 * Utility Class related HttpServletRequest.
 *
 * @version 1.0, 2014-10-10
 * @version 1.6, 2016-02-02  Providing management function by path of the node ID without classifying the node type
 * @version 1.7, 2017-04-04  The getJsonParam method returns with the Map&lt;String, ?&gt; format since 1.7.
 * @author  Jeasu Kim
 */
public class RequestUtil {
	private Map<String, ?> jsonParam = null;
	private HttpServletRequest request = null;
	private String templatePath  = null;
	private String collapseScope = null;

	private class MapDeserializerDoubleAsIntFix implements JsonDeserializer<Map<String, Object>>{
		@Override  @SuppressWarnings("unchecked")
		public Map<String, Object> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
			return (Map<String, Object>)read(json);
		}

		private Object read(JsonElement jElement) {
			if (jElement.isJsonArray()) {
				List<Object> list = new ArrayList<Object>();
				JsonArray jArray = jElement.getAsJsonArray();

				for (JsonElement jsonElement : jArray) {
					list.add(read(jsonElement));
				}

				return list;
			} else if (jElement.isJsonObject()) {
				Map<String, Object> map = new LinkedTreeMap<String, Object>();
				JsonObject jObject = jElement.getAsJsonObject();
				Set<Map.Entry<String, JsonElement>> entitySet = jObject.entrySet();

				for (Map.Entry<String, JsonElement> entry: entitySet){
					map.put(entry.getKey(), read(entry.getValue()));
				}

				return map;
			} else if (jElement.isJsonPrimitive()){
				JsonPrimitive jPrimitive = jElement.getAsJsonPrimitive();

				if (jPrimitive.isBoolean()) {
					return jPrimitive.getAsBoolean();
				} else if (jPrimitive.isString()) {
					return jPrimitive.getAsString();
				} else if (jPrimitive.isNumber()) {
					Number number = jPrimitive.getAsNumber();
					long   longValue   = number.longValue();
					double doubleValue = number.doubleValue();

					if (Math.ceil(Math.abs(doubleValue)) == Math.abs(longValue)) {
						if (longValue >= -2147483648 && longValue <= 2147483647) {
							return number.intValue();
						} else {
							return longValue;
						}
					} else {
						/*
						if (doubleValue >= 1.40239846E-45f && doubleValue <= 3.40282347E+38f) {
							return number.floatValue();
						} else {
							return doubleValue;
						}
						*/

						return doubleValue;
					}
				}
			}
		
			return null;
		}
	}

	/**
	 * Constructor for HttpServletRequest related Utility Class.
	 * 
	 * @param  request  Client request object.
	 */
	public RequestUtil(HttpServletRequest request) {
		String templatePath  = request.getServletContext().getInitParameter("jnode.templatePath");
		String collapseScope = request.getServletContext().getInitParameter("jnode.collapseScope");

		if (templatePath  == null)  templatePath  = "/WEB-INF/template";
		if (collapseScope == null)  collapseScope = "none";

		this.request       = request;
		this.templatePath  = templatePath;
		this.collapseScope = collapseScope;
	}

	/**
	 * This method retrieves the range that does not distinguish the template path.
	 * 
	 * <UL>
	 *   <LI><CODE>none</CODE> - By default, content is managed by the directory corresponding to the node type in the <CODE>content</CODE> directory that distinguishes content by node type.</LI>
	 *   <LI><CODE>content</CODE> - Content is not distinguished by node type in the <CODE>collapse</CODE> directory.</LI>
	 *   <LI><CODE>template</CODE> - Content is not distinguished by node type, and page also is not distinguished in the <CODE>collapse</CODE> directory.</LI>
	 * </UL>
	 * 
	 * @return cope of collapsed template path.
	 * @since  1.6
	 */
	public String getCollapseScope() {
		return this.collapseScope;
	}

	/**
	 * This method retrieves the node content ID for the template file requested by the front-end for use as the content of the node.
	 * 
	 * If jnode.collapseScope is not set, it is the same as /${nodeType}${nodeId}.
	 * If jnode.collapseScope does not distinguish by node type, it is the same as ${nodeId}.
	 * 
	 * @return Content ID.
	 */
	public String getContentId() {
		String statusCode = request.getParameter("error.status_code");
		String nodeType   = request.getParameter("nodeType");
		String nodeId     = request.getParameter("nodeId");

		String attrNodeId = (String)request.getAttribute("nodeId");
		if (!(attrNodeId == null || attrNodeId.trim().equals(""))) {
			nodeId = attrNodeId;
		}

		if (nodeId == null || nodeId.trim().equals(""))  nodeId = "/index";

		if (statusCode == null) {
			if (collapseScope.equals("none"))  return String.format("/%s%s", nodeType, nodeId);
			else                               return nodeId;
		} else {
			return String.format("/status/%s", nodeType);
		}
	}

	/**
	 * This method retrieves a RequestDispatcher object that outputs a template file according to the HTTP status code.
	 * 
	 * @param  statusCode  HTTP status code.
	 * @return A RequestDispatcher object that outputs a template file according to the HTTP status code.
	 */
	public RequestDispatcher getDispatcher(int statusCode) {
		request.setAttribute("javax.servlet.error.request_uri", request.getRequestURI());

		return request.getRequestDispatcher(String.format("%s/page/status/%d.jsp", templatePath, statusCode));
	}

	/**
	 * This method retrieves a RequestDispatcher object that outputs a template file corresponding to the template ID.
	 * 
	 * @param  templateId  Template ID.
	 * @return A RequestDispatcher object that outputs a template file corresponding to the template ID.
	 */
	public RequestDispatcher getDispatcher(String templateId) {
		return request.getRequestDispatcher(templatePath + templateId + ".jsp");
	}

	/**
	 * This method retrieves a RequestDispatcher object that outputs a template file for the node content corresponding to the nodeType and nodeId.
	 * 
	 * @param  nodeType  Node Type.
	 * @param  nodeId    Node ID.
	 * @return A RequestDispatcher object that outputs a template file for the node content corresponding to the nodeType and nodeId.
	 */
	public RequestDispatcher getDispatcher(String nodeType, String nodeId) {
		return request.getRequestDispatcher(String.format("%s/content/%s%s.jsp", templatePath, nodeType, nodeId));
	}

	/**
	 * This method converts the parameters from the HttpServletRequest containing the parameters of the form data type into a Map object.
	 * 
	 * @return The Map object that is converted from the parameters requested by the Client.
	 */
	public Map<String, ?> getFormParam() {
		Map<String, Object> formParam = new HashMap<String, Object>();

		Map<String, String[]> formParams = request.getParameterMap();
		Set<String> paramSet = formParams.keySet();
		for (String key : paramSet) {
			String[] values = formParams.get(key);
			if (values.length == 1)  formParam.put(key, values[0]);
			else                     formParam.put(key, values);
		}

		return formParam;
	}

	/**
	 * This method converts a JSON notation string containing an array into a List object.
	 * 
	 * @param  listJson  The JSON notation string containing the array.
	 * @param  type      Type to reflect as a Java object.
	 * @return A List object that converts the array notation string.
	 * @deprecated  As of Version 1.7 of the Jnode Framework.
	 */
	public List<?> getJsonList(String listJson, Type type) {
		return new Gson().fromJson(listJson, type);
	}

	/**
	 * This method converts the parameters of the JSON notation string contained in the HttpServletRequest to a Map object.
	 * 
	 * Up to version 1.6 of the Jnode Framework, only Map<String, String> format could be converted.
	 * However, since version 1.7 of the Jnode Framework, the Map<String, ?> format can be converted.
	 * 
	 * @return A Map object that is converted from the parameters of the JSON notation string requested by the Client.
	 */
	public Map<String, ?> getJsonParam() {
		return getJsonParam(false);
	}

	/**
	 * This method converts the parameters of the JSON notation string contained in the HttpServletRequest to a Map object.
	 * 
	 * @param  stringOnly  Whether the Map object only contains a string as a value.
	 * @return A Map object that is converted from the parameters of the JSON notation string requested by the Client.
	 * @since  1.7
	 */
	public Map<String, ?> getJsonParam(boolean stringOnly) {
		if (jsonParam == null) {
			try {
				String reqJson = IOUtils.toString(request.getInputStream(), "UTF-8");

				if (stringOnly) {
					jsonParam = new Gson().fromJson(reqJson, new TypeToken<Map<String,String>>(){}.getType());
				} else {
					Gson gson = new GsonBuilder().registerTypeAdapter(new TypeToken<Map<String, Object>>(){}.getType(), new MapDeserializerDoubleAsIntFix()).create();
					jsonParam = gson.fromJson(reqJson, new TypeToken<Map<String, Object>>(){}.getType());
				}
			} catch(IOException | JsonSyntaxException e) {
				jsonParam = new HashMap<String, Object>();
			}
		}

		return jsonParam;
	}

	/**
	 * This method retrieves the Page ID for the template file requested by front-end for use as page.
	 * 
	 * Page ID is the same as URI excluding the context path and the extension.
	 * 
	 * @return Page ID.
	 */
	public String getPageId() {
		String servletPath = request.getServletPath();

		if (servletPath.endsWith("/$")) {
			servletPath = request.getRequestURI().substring(request.getContextPath().length()).split("/[$]/")[0];
		}

		int pathIndex = servletPath.lastIndexOf("/");
		int extIndex  = servletPath.lastIndexOf(".");

		if ((extIndex < 1) || (pathIndex > extIndex)) {
			if (!servletPath.endsWith("/"))  servletPath += "/";

			// NOTE: Limit file name to index excluding extension of welcome page according to directory request
			return servletPath + "index";
		} else {
			return servletPath.substring(0, extIndex);
		}
	}

	/**
	 * This method retrieves the page ID that is processed when the template file requested by the front-end for use as a page is in not state code 200.
	 * 
	 * @param  statusCode  Status code.
	 * @return Page ID based on status code
	 */
	public String getPageId(int statusCode) {
		return String.format("/status/%d", statusCode);
	}

	/**
	 * This method retrieves the Page ID for template file corresponding to requestURI including context path.
	 * 
	 * This method retrieves the Page ID by excluding the context path and its extension in requestURI.
	 * If requestURI does not have an extension, it is assumed to be a directory, and the index file in that directory is used.
	 * 
	 * @param  requestURI  A URI that contains the context path.
	 * @return Page ID.
	 */
	public String getPageId(String requestURI) {
		int contextPathLength = request.getContextPath().length();
		int extIndex          = requestURI.lastIndexOf(".");

		if (extIndex < 1) {
			String requestURIExcludedContextPath = requestURI.substring(contextPathLength);
			if (!requestURIExcludedContextPath.endsWith("/"))  requestURIExcludedContextPath += "/";

			// NOTE: Limit file name to index excluding extension of welcome page according to directory request
			return requestURIExcludedContextPath + "index";
		} else {
			return requestURI.substring(contextPathLength, extIndex);
		}
	}

	/**
	 * This method retrieves the status code of page.
	 * 
	 * @return The status code of page.
	 */
	public int getPageStatusCode() {
		return getPageStatusCode(request.getRequestURI());
	}

	/**
	 * This method parses the requestURI including the context path to get the page status code.
	 * 
	 * If you do not use error handling in the Jnode Framework, you can get an incorrect value.
	 * 
	 * @param  requestURI  A URI that contains the context path.
	 * @return The status code of page.
	 */
	public int getPageStatusCode(String requestURI) {
		String pageId = getPageId(requestURI);
		
		int statusCode = 200;

		if (pageId.matches("^/status/\\d\\d\\d$")) {
			try {
				statusCode = Integer.parseInt(pageId.substring(8));
			} catch (NumberFormatException e) {}
		}

		return statusCode;
	}

	/**
	 * This method gets the ID for the template file requested by the front-end.
	 * 
	 * The template file requested in the front-end is used as content of the node or page.
	 * If jnode.collapseScope is not set, template ID is the same as /content/${nodeType}${nodeId} or /page${uri_without_context_ext}, respectively.
	 * If jnode.collapseScope is set to content, Only /collapse${nodeId} for the content of the node.
	 * If you set jnode.collapseScope to template, In all cases, template ID starts with /collapse,
	 * and the content of the node or page becomes /collapse${nodeId} or /collapse${uri_without_context_ext}, respectively.
	 * 
	 * ${uri_without_context_ext} means a URI excluding the context path and the extension.
	 * 
	 * @return Template ID.
	 */
	public String getTemplateId() {
		String requireType = request.getParameter("requireType");
		String nodeType    = request.getParameter("nodeType");

		if (requireType == null || nodeType == null) {
			if (collapseScope.equals("none"))  return "/page" + getPageId();
			else                               return "/collapse" + getPageId();
		} else if (requireType.equals("content")) {
			if (request.getParameter("error.status_code") == null) {
				if (collapseScope.equals("none"))  return "/content"  + getContentId();
				else                               return "/collapse" + getContentId();
			} else {
				if (request.getServletPath().endsWith("/content/status/default.ejs")) {
					return "/content/status/default";
				} else {
					return "/content/status/"  + nodeType;
				}
			}
		} else {
			return "/controller/" + nodeType;
		}
	}

	/**
	 * This method retrieves the template ID that is processed when the template file requested by the front-end for use as a page is in not state code 200.
	 * 
	 * @param  statusCode  Status code.
	 * @return Template ID according to status code.
	 */
	public String getTemplateId(int statusCode) {
		return "/page" + getPageId(statusCode);
	}

	/**
	 * This method gets the path that manages the template files.
	 * 
	 * @return The path to manage the template files.
	 */
	public String getTemplatePath() {
		return this.templatePath;
	}
}