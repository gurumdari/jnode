/*
 * @(#)DateFormatFunction.java  1.3, 2015-04-04
 */
package com.jnodeframework.util;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.google.gson.Gson;

/**
 * Function class that generates the i18n JSON notation string associated with the date format to be used in the $module$.date.Formatter JavaScript object.
 * 
 * @version 1.3, 2015-04-04
 * @author  Jeasu Kim
 */
public class DateFormatFunction {

	/**
	 * This method creates an internationalization(i18n) JSON notation string related to the date format
	 * to be used in the $module$.date.Formatter JavaScript object.
	 * 
	 * @param  langObj  A java.lang.String or java.util.Locale object representing the language information.
	 * @return The i18n JSON notation string related to the date format.
	 */
	public static String getDateI18n(Object langObj) {
		Locale locale = null;

		if      (langObj instanceof Locale)  locale = (Locale)langObj;
		else if (langObj instanceof String)  locale = new Locale((String)langObj);
		else                                 throw new RuntimeException("Not defined parameter instance type.");

		return getDateI18nJson(locale);
	}

	/**
	 * This function creates an internationalization(i18n) JSON notation string related to the date format
	 * only for languages not defined in the $module$.date.Formatter JavaScript object.
	 * 
	 * @param  langObj  A java.lang.String or java.util.Locale object representing the language information.
	 * @return The i18n JSON notation string related to the date format.
	 */
	public static String getDateI18nNotdefined(Object langObj) {
		Locale locale = null;

		if      (langObj instanceof Locale)  locale = (Locale)langObj;
		else if (langObj instanceof String)  locale = new Locale((String)langObj);
		else                                 throw new RuntimeException("Not defined parameter instance type.");

		String lang = locale.getLanguage();

		if (lang.equals("en") || lang.equals("ko") || lang.equals("zh") || lang.equals("ja")) {
			return "{\"lang\":\"" + lang + "\"}";
		} else {
			return getDateI18nJson(locale);
		}
	}

	/**
	 * This method creates an internationalization(i18n) JSON notation string related to the date format
	 * to be used in the $module$.date.Formatter JavaScript object.
	 * 
	 * @param  locale  Locale object
	 * @return The i18n JSON notation string related to the date format.
	 */
	private static String getDateI18nJson(Locale locale) {
		DateFormatSymbols dateFormatSymbols = new DateFormatSymbols(locale);
		String[] shortMonthNames   = dateFormatSymbols.getShortMonths();
		String[] longMonthNames    = dateFormatSymbols.getMonths();
		String[] shortWeekdayNames = dateFormatSymbols.getShortWeekdays();
		String[] longWeekdayNames  = dateFormatSymbols.getWeekdays();
		String[] ampmNames         = dateFormatSymbols.getAmPmStrings();

		String[] monthNames   = new String[24];
		String[] weekdayNames = new String[14];

		for (int i = 0; i < 12; i++) {
			monthNames[i] = shortMonthNames[i];
		}

		for (int i = 0; i < 12; i++) {
			monthNames[i + 12] = longMonthNames[i];
		}

		for (int i = 0; i < 7; i++) {
			weekdayNames[i] = shortWeekdayNames[i + 1];
		}

		for (int i = 0; i < 7; i++) {
			weekdayNames[i + 7] = longWeekdayNames[i + 1];
		}

		Map<String, String[]> symbolsMap = new HashMap<String, String[]>();
		symbolsMap.put("MonthNames"  , monthNames  );
		symbolsMap.put("WeekdayNames", weekdayNames);
		symbolsMap.put("AmpmNames"   , ampmNames   );

		Map<String, String> dateStyleMap = new HashMap<String, String>();
		dateStyleMap.put("SHORT" , ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.SHORT , locale)).toPattern());
		dateStyleMap.put("MEDIUM", ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.MEDIUM, locale)).toPattern());
		dateStyleMap.put("LONG"  , ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.LONG  , locale)).toPattern());
		dateStyleMap.put("FULL"  , ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.FULL  , locale)).toPattern());

		Map<String, String> timeStyleMap = new HashMap<String, String>();
		timeStyleMap.put("SHORT" , ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.SHORT , locale)).toPattern());
		timeStyleMap.put("MEDIUM", ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.MEDIUM, locale)).toPattern());
		timeStyleMap.put("LONG"  , ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.LONG  , locale)).toPattern());
		timeStyleMap.put("FULL"  , ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.FULL  , locale)).toPattern());

		Map<String, Map<String, ?>> dateMuiMap = new HashMap<String, Map<String, ?>>();
		dateMuiMap.put("Symbols"  , symbolsMap  );
		dateMuiMap.put("DateStyle", dateStyleMap);
		dateMuiMap.put("TimeStyle", timeStyleMap);

		Gson gson = new Gson();
		return gson.toJson(dateMuiMap);
	}
}