<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	parse_str(parse_url($_SERVER['REQUEST_URI'], PHP_URL_QUERY), $request_dataset);

	if (array_key_exists('id', $request_dataset)) {
		$dataset_id = urldecode($request_dataset['id']);

		if(!isset($_SESSION))  session_start();
		$dataset = $_SESSION[$dataset_id];

		if ($dataset == null) {
			$jnode->sendError(404);
		} else {
			setcookie('Jnode-Frontend-Id', $dataset_id, time() - 3600, '/');
			unset($_SESSION[$dataset_id]);

			header("Content-Type: text/javascript; charset=UTF-8");
			echo "\$jnode\$.dataset=$dataset;\$dataset\$=\$jnode\$.dataset;";
		}
	} else {
		$jnode->sendError(404);
	}
}