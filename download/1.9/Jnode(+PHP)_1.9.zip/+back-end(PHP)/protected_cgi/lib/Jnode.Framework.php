<?php
/*
 * Copyright(C) gurumdari.com ALL RIGHT RESERVED.
 *
 * Please refer to the following address for details.
 * http://jnodeframework.com
 */
namespace Gurumdari;

/**
 * +PHP Jnode framework allows the back-end environment to be used in addition to back-end PHP functionality for the Jnode Framework when it is a PHP interpreter environment.
 *
 * +PHP Jnode framework is supported since PHP 7.0.
 *
 * @author Jeasu Kim
 */
class Jnode {

	/**
	 * Jnode Framework +PHP back-end module version.
	 */
	public static $VERSION        = '1.9';

	/**
	 * The public_html directory path that manages static files such as CSS, JavaScript, and image.
	 */
	public static $HTML_HOME      = '';

	/**
	 * The protected_cgi directory path that manages Jnode Framework PHP libraries and template files.
	 */
	public static $CGI_HOME       = '';

	/**
	 * The template directory path that manages template files. Default is ${web_domain_root}/protected_cgi/template.
	 */
	public static $TEMPLATE_PATH  = '';

	/**
	 * The URI path of the front-end renderer.
	 */
	public static $RENDERER_URI   = '';

	/**
	 * The range that does not distinguish the directory of the template file according to the node type. (<B>none</B> | content | template)
	 */
	public static $COLLAPSE_SCOPE = 'none';

	/**
	 * HTML5-based Internet Explorer version to allow. (<B>0</B> | 9 | 10 | 11)
	 */
	public static $ACCEPT_IE      = 0;

	/**
	 * The URI pattern to recognize as an AJAX request. Default is "/^\/ajax(\/.+)\.json$/i".
	 */
	public static $AJAX_PATTERN   = "/^\/ajax(\/.+)\.json$/i";

	/**
	 * The mods directory path that manages PHP add-on modules. Default is ${web_domain_root}/protected_cgi/lib/mods.
	 */
	public static $MOD_PATH       = '';

	/**
	 * List of PHP add-on modules to register. Default is ["*"].
	 */
	public static $MOD_LIST       = ['*'];

	/**
	 * JavaScript execution command.
	 */
	public static $JS_EXEC        = null; // "node" || "${path_to_path}/jdk${version}/bin/jjs";

	/**
	 * Whether to use the rendered result of the previously invoked JavaScript-based template file.
	 */
	public static $PRECOMPILE     = false;

	/**
	 * This function registers the specified $mods in the PHP modules in the ${protected_cgi_path}/lib/mods directory.
	 *
	 * The PHP modules is set to be registered as an array of relative PHP files based on the directory set in the this::$MOD_PATH property.
	 * The default value for the directory set in the this::$MOD_PATH property is ${protected_cgi_path}/lib/mods.
	 * If you want to register all of the PHP files in a particular directory, including the child directory path, you can use *.
	 *
	 * If $mods is null, the value of the this::$MOD_LIST property is set.
	 * The default value for the array set in the this::$MOD_LIST property is ["*"].
	 *
	 * this::$MOD_PATH property and this::$MOD_LIST property can be set in mod_path key and mod_list key
	 * in the ${web_domain_root}/protected_cgi/lib/conf/jnode.selector.json file, respectively.
	 *
	 * @param  $mods  List of PHP modules to register.
	 */
	public function registMods(array $mods = null) {
		if (file_exists($this::$MOD_PATH)) {
			if (is_null($mods))  $mods = $this::$MOD_LIST;

			if (count($mods) == 1 && $mods[0] == '*') {
				$this->requireRecursive($this::$MOD_PATH.'/*');
			} else {
				foreach ($mods as $mod) {
					$this->requireRecursive("{$this::$MOD_PATH}/".str_replace("\\", "/", $mod));
				}
			}
		}
	}

	/**
	 * This function is designed to block access when the client web browser is a version of Internet Explorer 8 or later that does not support HTML5 or Netscape,
	 * and to output a ${template_home}/page/status/415.html page that guides the use of other web browsers that support HTML5.
	 *
	 * The allowable version of Internet Explorer is processed by the value of the this::$ACCEPT_IE property.
	 * Since HTML5 is still a feature that is continuously added, even if it is Internet Explorer 9 or later that supports HTML5,
	 * it is strongly tied to OS system, the development has been stopped with version 11, we consider Internet Explorer itself to be an inappropriate web browser.
	 * So, the default value of this::$ACCEPT_IE Property is set to 0. The this::$ACCEPT_IE property can be set to the accept_ie key
	 * in the ${web_domain_root}/protected_cgi/lib/conf/jnode.selector.json file.
	 *
	 * This function is not just only to block access to web browsers that do not support HTML5.
	 * Even though it is a version that supports HTML5 due to the compatibility view feature of Internet Explorer, for environments using lower version,
	 * it also provides a function to ignore the client setting and use the latest version.
	 */
	public function checkHTML5() {
		$user_agent       = '';
		$deny_client      = false;
		$detected_browser = '';

		// When accessing URL Open, there may be no user-agent.
		if (array_key_exists('HTTP_USER_AGENT', $_SERVER))  $user_agent = $_SERVER['HTTP_USER_AGENT'];

		$accept_ie_version = intval($this::$ACCEPT_IE);
		$msie_version      = 8;

		if ($accept_ie_version < 9 || $accept_ie_version > 11)  $accept_ie_version = 0;

		if (strpos($user_agent, 'Trident') || strpos($user_agent, 'MSIE')) {
			$detected_browser = 'ie';

			if (preg_match("/Trident\/(\d+\.\d+)/", $user_agent, $trident_matcher)) {
				$msie_version = floatval($trident_matcher[1]) + 4;
			} elseif (preg_match("/MSIE\s(\d+\.\d+)/", $user_agent, $msie_matcher)) {
				$msie_version = floatval($msie_matcher[1]);
			}

			if ($accept_ie_version == 0 || $msie_version < $accept_ie_version) {
				$deny_client = true;
			}

			header('X-UA-Compatible', 'IE=Edge');
		} elseif (strpos($user_agent, 'Navigator')) {
			$accept_ie_version = 0;
			$detected_browser = 'navigator';
			$deny_client = true;
		}

		if ($deny_client) {
			$alter_browser = '';
			$nt_version = 6;  # Based on Windows 7

			if (strpos($user_agent, 'Windows NT')) {
				if (preg_match("/Windows NT (\d+\.\d+)/", $user_agent, $windows_matcher)) {
					$nt_version = floatval($windows_matcher[1]);

					if ($nt_version > 9) {
						$alter_browser = 'Edge';
						if ($detected_browser == 'ie')  $detected_browser = 'edge';
					}
				}
			} elseif (strpos($user_agent, 'Mac OS X')) {
				$alter_browser = 'Safari';
			}

			$accept_version = ($accept_ie_version == 0 ? '' : (string)$accept_ie_version);
			$support_html5  = ($msie_version > 8 ? 'html5' : '');
			$error_message  = '';
			$guide_message  = '';


			if ($detected_browser == 'navigator')  $error_message = 'You cannot access with Netscape Navigator.';
			elseif ($accept_ie_version ==  0)      $error_message = 'You cannot access with Internet Explorer.';
			elseif ($accept_ie_version ==  9)      $error_message = 'Please check if your browser supports HTML5.';
			else                                   $error_message = "You should access with internet explorer ver.{$accept_ie_version} or higher.";

			if ($accept_ie_version > 8) {
				$guide_message = "Please use another browser that supports HTML5 if you are unable to use internet explorer ver.{$accept_ie_version} or higher.";
			} elseif ($alter_browser == '') {
				$guide_message = 'Please use another browser that supports HTML5.';
			} else {
				$guide_message = "Please use {$alter_browser} or another browser that supports HTML5.";
			}

			# http_response_code(415);
			header((isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0')." 415 $error_message", true, 415);

			include $this::$TEMPLATE_PATH.'/page/status/415.html';
			exit;
		}
	}

	/**
	 * In the ${web_domain_root}/protected_cgi/template/page, the requested page template file is found.
	 * If the this::$COLLAPSE_SCOPE property is template, the node content template file
	 * and the page template file are managed independently in the ${web_domain_root}/protected_cgi/template/collapse directory.
	 * The this::$COLLAPSE_SCOPE property is set in the collapse_scope key in the ${web_domain_root}/protected_cgi/lib/conf/jnode.selector.json file.
	 *
	 * The file with the .html extension in the ${web_domain_root}/protected_cgi/template directory is actually a PHP file,
	 * but +PHP Jnode framework separates the file handling the logic and the file for screen output physically
	 * by adding the .php extension and the .html extension to Page ID respectively.
	 * At this point, you can omit the file with the .php extension if you do not have logic involved.
	 *
	 * @param  $page_id      Page ID requested.
	 * @param  $template     Template type requested.
	 * @param  $jnode_param  Parameters to be passed to the requested template page file.
	 */
	public function requirePage(string $page_id, string $template = 'html', array $jnode_param = []) {
		$extension    = $template;
		$template_ext = explode('.', $template);

		if (count($template_ext) == 2) {
			$template  = $template_ext[0];
			$extension = $template_ext[1];
		}

		$file_id = $this::$TEMPLATE_PATH.($this::$COLLAPSE_SCOPE == 'template' ? '/collapse' : '/page').$page_id;
		$template_file = "$file_id.$extension";

		if (file_exists($template_file)) {
			set_error_handler([$this, 'handleContentException']);

			try {
				$jnode = $this;
				chdir(dirname($template_file));

				if ($extension != 'php' && file_exists("$file_id.php")) {
					require "$file_id.php";
				}

				if (isset($jnode_dataset)) {
					$dataset_id = str_replace('=', '', base64_encode(date("Y-m-d\TH:i:s")));
					setcookie('Jnode-Frontend-Id', $dataset_id, 0, '/');

					if(!isset($_SESSION))  session_start();
					$_SESSION[$dataset_id] = is_array($jnode_dataset) ? json_encode($jnode_dataset) : $jnode_dataset;
				}

				if ($template == 'html' || $template == 'php') {
					require $template_file;
				} else if (isset($this::$JS_EXEC)) {
					$precompile      = false;
					$precompile_file = null;
					$complied_value  = null;

					$server_options = [
						'server' => [
							'version'       => $this::$VERSION,
							'templateType'  => $template,
							'collapseScope' => $this::$COLLAPSE_SCOPE
						]
					];

					if (isset($jnode_dataset)) {
						$server_options['options'] = is_array($jnode_dataset) ? $jnode_dataset: json_decode($jnode_dataset, true);
						// TODO: Consider skipping even if options are the same
					} else if ($this::$PRECOMPILE) {
						$precompile = true;
					}

					if ($precompile) {
						$precompile_file = $this::$TEMPLATE_PATH.'/precompile'.($this::$COLLAPSE_SCOPE == 'template' ? '/collapse' : '/page')."$page_id.$extension";

						if (file_exists($precompile_file)) {
							if (filemtime($template_file) < filemtime($precompile_file)) {
								$complied_value = file_get_contents($precompile_file);
							}
						} else {
							$precompile_dir = dirname($precompile_file);
							if (!file_exists($precompile_dir)) {
								if (!@mkdir($precompile_dir, 0777, true)) {
									$precompile = false;
									error_log("Jnode Notice: mkdir(): Permission denied during making directory \"$precompile_dir\" for precompile.");
								}
							}
						}
					}

					if (is_null($complied_value)) {
						$template_engine = $this::$CGI_HOME."/lib/template/$template.js";

						try {
							$jnode_substitutor = $_POST;
							if (isset($jnode_dataset))  $jnode_substitutor = array_merge($jnode_substitutor, $jnode_dataset);

							$server_options['value'] = $this->getIncludeValue($template_file, $extension, null, $this, $jnode_substitutor);
							$arg_sep = null;

							$commands = [
								$this::$JS_EXEC,
								$template_engine
							];

							$js_exec_wo_ext = strtolower($this::$JS_EXEC);
							if (substr($js_exec_wo_ext, -4) == '.exe')  $js_exec_wo_ext = substr($js_exec_wo_ext, 0, -4);
							if (substr($js_exec_wo_ext, -3) == 'jjs' )  $arg_sep = '--';

							$bridge = new \Gurumdari\CommandBridge();
							$complied_value = $bridge->call($commands, $server_options, $arg_sep);

							if ($precompile) {
								if (@file_put_contents($precompile_file, $complied_value) === false) {
									error_log("Jnode Notice: file_put_contents(): Permission denied during writing file \"$precompile_file\" for precompile.");
								}
							}
						} catch (\Exception $e) {
							$error_message = str_replace($template_engine, "/lib/template/$template.js", $e->getMessage());
							if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
								$error_message = str_replace(realpath($template_engine), "/lib/template/$template.js", $error_message);
							}

							$this->sendError(500, $error_message, (get_class($e) == 'ErrorException' ? $e->getSeverity() : 1024));
						}
					}

					echo $complied_value;
				} else {
					$this->sendError(500, 'Not defined JavaScript execution command.');
				}
			} catch (\Error $e) {
				$this->displayContentException($e->getMessage(), $e->getFile(), $e->getLine(), 256);
			} catch (\Exception $e) {
				$this->displayContentException($e->getMessage(), $e->getFile(), $e->getLine(), (get_class($e) == 'ErrorException' ? $e->getSeverity() : 1024));
			}
		} else {
			$this->sendError(404);
		}
	}

	/**
	 * +PHP Jnode framework finds the requested node content in the ${web_domain_root}/protected_cgi/template directory,
	 * which manages the template file. The this::$COLLAPSE_SCOPE property determines whether the content type should be subdirectory separated.
	 * If it is none, it manages by content type directories in content directory.
	 * If it is content, it manages in collapse directory without distinction.
	 * If it is template, the page request files are also managed in the collapse directory.
	 * The this::$COLLAPSE_SCOPE property is set in the collapse_scope key in the ${web_domain_root}/protected_cgi/lib/conf/jnode.selector.json file.
	 *
	 * The parameters requested by the front-end are passed to the POST method.
	 * When the back-end data is set in the $jnode_dataset, data is bound in the JSON notation string to the front-end along with the template file.
	 * When the template is rendered, data are automatically used.
	 * Also, the data that is bound is set in the dataset object of the rendering JavaScript object,
	 * so it can be used when implementing according to the client's event.
	 *
	 * @param  $node_type  Node content type requested.
	 * @param  $node_id    Node content ID requested.
	 * @param  $template   Template type requested.
	 */
	public function requireContent(string $node_type, string $node_id, string $template = 'ejs') {
		$template_id = ($this::$COLLAPSE_SCOPE == 'none' ? "/content/$node_type" : '/collapse').$node_id;
		$file_id = $this::$TEMPLATE_PATH.$template_id;

		set_error_handler([$this, 'handleContentException']);

		try {
			$jnode = $this;

			if (file_exists("$file_id.php")) {
				chdir(dirname("$file_id.php"));

				set_error_handler([$this, 'handleContentException']);

				require "$file_id.php";

				if (isset($_REQUEST['forward_node_id'])) {
					$template_id = ($this::$COLLAPSE_SCOPE == 'none' ? "/content/$node_type" : '/collapse').$_REQUEST['forward_node_id'];
					$file_id = $this::$TEMPLATE_PATH.$template_id;
				}

				if (isset($jnode_dataset)) {
					$plain_delimiter = "Jnode-Response-Delimiter_".date("Y-m-d\TH:i:s");
					$delimiter = base64_encode($plain_delimiter);

					header("Jnode-Response-Delimiter: $delimiter");

					echo is_array($jnode_dataset) ? json_encode($jnode_dataset) : $jnode_dataset;
					echo "\"\"''<-------- $delimiter -------->''\"\"";
				}
			}

			$template_file = "$file_id.$template";

			$lang_subfix = '';
			if (isset($_POST['blang'])) {
				$template_file = "{$file_id}_{$_POST['blang']}.$template";

				if (!file_exists($template_file) && ($template == 'node')) {
					$template_file = "{$file_id}_{$_POST['blang']}.html";
				}

				if (!file_exists($template_file)) {
					$template_file = "$file_id.$template";
				}
			}

			if (!file_exists($template_file) && ($template == 'node')) {
				$template_file = "$file_id.html";
			}

			if (file_exists($template_file)) {
				chdir(dirname($template_file));

				if ($template == 'node' || $template == 'html') {
					require $template_file;
				} else {
					$jnode_substitutor = $_POST;
					if (isset($jnode_dataset))  $jnode_substitutor = array_merge($jnode_substitutor, $jnode_dataset);

					echo $this->getIncludeValue($template_file, $template, $node_type, $this, $jnode_substitutor);
				}
			} else {
				$this->sendContentError($node_type, [
					'status_code' => 404,
					'template'    => $template,
					'message'     => "The template file for the $node_type node is not found.",
					'stack'       => "The template file for the $node_type node is not found."
				]);
			}
		} catch (\Error $e) {
			$this->displayContentException($e->getMessage(), $e->getFile(), $e->getLine(), 256);
		} catch (\Exception $e) {
			$this->displayContentException($e->getMessage(), $e->getFile(), $e->getLine(), (get_class($e) == 'ErrorException' ? $e->getSeverity() : 1024));
		}
	}

	/**
	 * This function forwards the node content to the $node_id.
	 * 
	 * @param  $node_id          Node ID to be forwarded to
	 * @param  $reload_renderer  Whether to reload the Stylesheet and Script files corresponding to $node_id
	 * @since  Jnode Framework 1.9
	 */
	public function forwardContent(string $node_id, bool $reload_renderer = false) {
		$_REQUEST['forward_node_id'] = $node_id;

		if ($reload_renderer === true) {
			header("Jnode-Forward-Node-Id: $node_id");
		}
	}

	/**
	 * This method transcompiles the request URI.
	 *
	 * @param  $request_uri  The request URI
	 * @param  $options      The options for transcompiling
	 * @since  Jnode Framework 1.9
	 */
	function transcompileURI(string $request_uri, array $options) {
		$content_type    = $options['content_type'];
		$request_file    = $this::$HTML_HOME.$request_uri;
		$precompile_file = "{$this::$TEMPLATE_PATH}/precompile";

		if (isset($this::$RENDERER_URI)) {
			$request_subfix = ($this::$COLLAPSE_SCOPE == 'template' ? '/collapse' : '/page').$request_uri;
			$renderer_len   = strlen($this::$RENDERER_URI);

			if (substr($request_uri, 0, $renderer_len) === $this::$RENDERER_URI) {
				$request_subfix = substr($request_uri, $renderer_len);
			}

			$precompile_file .= $request_subfix;
			$request_file = $this::$TEMPLATE_PATH.$request_subfix;

			if (!file_exists($request_file)) {
				$request_file = $this::$HTML_HOME.$request_uri;
			}
		} else {
			$precompile_file .= "/page$request_uri";
		}

		if (file_exists($request_file)) {
			$value = null;

			$parent_exist = false;

			if ($this::$PRECOMPILE) {
				if (file_exists($precompile_file) && (filemtime($request_file) < filemtime($precompile_file))) {
					$value = file_get_contents($precompile_file);
				} else {
					$precompile_dir = dirname($precompile_file);
					$parent_exist   = true;

					if (!file_exists($precompile_dir)) {
						if (!@mkdir($precompile_dir, 0777, true)) {
							$parent_exist = false;
							error_log("Jnode Notice: mkdir(): Permission denied during making directory \"$precompile_dir\" for precompile.");
						}
					}
				}
			}

			if (is_null($value)) {
				try {
					$extension = strtolower(pathinfo($request_file)["extension"]);
					if ($extension == 'less') {
						if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
							// If it is not installed as source and installed as a repository, it will not find the node executable.
							putenv('PATH=/usr/bin:/usr/local/bin:'.getenv('PATH'));
						}
	
						$commands = [
							'lessc',
							$request_file
						];
	
						$bridge = new \Gurumdari\CommandBridge();
						$value = $bridge->call($commands);
					} else if ($extension == 'coffee') {
						if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
							// If it is not installed as source and installed as a repository, it will not find the node executable.
							putenv('PATH=/usr/bin:/usr/local/bin:'.getenv('PATH'));
						}
	
						$commands = [
							'coffee',
							'-bp',
							$request_file
						];
	
						$bridge = new \Gurumdari\CommandBridge();
						$value = $bridge->call($commands);
					} else if (isset($options['ts_target'])) {
						$out_file = '/dev/stdout';
	
						if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
							// The cmd of Windows can not use "/dev/stdout", so transcompiled files should be stored.
							if ($this::$PRECOMPILE) {
								$out_file = $precompile_file;
							} else {
								$this->sendError(500, "If the server is Windows and ".($extension == "ts" ? "the extension is ts" : "the target of js extension is es5").", The jnode.precompile context-param should be true");
							}
						} else {
							// If it is not installed as source and installed as a repository, it will not find the node executable.
							putenv('PATH=/usr/bin:/usr/local/bin:'.getenv('PATH'));
						}
	
						$commands = [
							'tsc',
							'--target',
							$options['ts_target'],
							'--outFile',
							$out_file,
							'--allowJs',
							$request_file
						];
	
						$bridge = new \Gurumdari\CommandBridge();
	
						if ($out_file = '/dev/stdout') {
							$value = $bridge->call($commands);
						} else {
							$bridge->call($commands);
							$value = file_get_contents($precompile_file);
						}
					} else {
						$value = file_get_contents($request_file);
					}
	
					if ($options['minify']) {
						if ($content_type == 'text/css') {
							// Remove comments
							$value = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $value);
	
							// Remove whitespace
							$value = preg_replace('/\s{2,}/', ' ', $value);
	
							// Remove space of comma, colons, semicolons and block.
							$value = preg_replace('/\s*;\s*}/', '}', $value);
							$value = preg_replace('/\s*(,|:|;|{|})\s*/', "$1", $value);
						} else if ($content_type == 'text/javascript') {
							// release v1.3.1
							// https://github.com/tedious/JShrink
							$value = \JShrink\Minifier::minify($value);
	
							// Convert unicode
							// ∵ The Edge using the EdgeHTML egine browser incorrectly recognizes the encoding of the cached JavaScript file.
							$value = json_encode($value);
							$value = preg_replace("/^\\\\u([a-f0-9]{3})/", "\\\\\\\\u$1", $value);
							$value = preg_replace("/([^\\\\])\\\\u([a-f0-9]{3})/", "$1\\\\\\\\u$2", $value);
							$value = preg_replace("/([^\\\\])((\\\\\\\\)*)\\\\\\\\\\\\u/", "$1$2\\\\\\\\\\\\\\\\u", $value);
							$value = json_decode($value);
						}
					}
				} catch (\Error $e) {
					$this->sendError(500, $e->getMessage(), (get_class($e) == 'ErrorException' ? $e->getSeverity() : 1024));
				} catch (\Exception $e) {
					$this->sendError(500, $e->getMessage(), (get_class($e) == 'ErrorException' ? $e->getSeverity() : 1024));
				}
	

				if ($parent_exist) {
					if (@file_put_contents($precompile_file, $value) === false) {
						error_log("Jnode Notice: file_put_contents(): Permission denied during writing file \"$precompile_file\" for precompile.");
					}
				}
			}

			header("Content-Type: $content_type; charset=UTF-8");
			echo $value;
		} else {
			$this->sendError(404);
		}
	}

	/**
	 * When a request is made with a URI matching the regular expression pattern defined in the this::$AJAX_PATTERN property,
	 * it is regarded as an AJAX request and the file of the path of the regular expression's capturing group value
	 * is read from the ${web_domain_root}/protected_cgi/template/ajax directory.
	 *
	 * If the data from the front-end is contained in a Body in JSON notation string,
	 * you can use $jnode_jparam, which is automatically converted to PHP's associative array.
	 * When the response result is contained in an associative array of $jnode_dataset,
	 * it is automatically converted to JSON notation string and forwarded to front-end.
	 */
	public function requireAJAX() {
		$ajax_file = null;

		if (preg_match($this::$AJAX_PATTERN, $_SERVER['REQUEST_URI'], $ajax_matcher)) {
			if (isset($ajax_matcher[1]))  $ajax_file = $this::$TEMPLATE_PATH."/ajax$ajax_matcher[1].php";
		}

		if (empty($ajax_file)) {
			$this->displayAJAXException(500, "Request URI (\"{$_SERVER['REQUEST_URI']}\") is not match with the regular expression pattern (\"".$this::$AJAX_PATTERN."\") for AJAX.");
		} elseif (file_exists($ajax_file)) {
			try {
				$content_type_header = $this->getRequestHeader('content-type', true); // EXAMPLE: multipart/form-data; boundary=----WebKitFormBoundaryY6qkULrRrLRTrb9q
				$accept_header       = $this->getRequestHeader('accept', true);

				if (empty($content_type_header)) {
					$content_type_header = 'application/json';
				}

				if (empty($accept_header)) {
					$accept_header = 'application/json';
				}

				set_error_handler([$this, 'handleAJAXException']);

				$jnode = $this;

				if (($_SERVER['REQUEST_METHOD'] == 'POST') && (strpos(strtolower($content_type_header), 'application/json') === 0)) {
					try {
						$jnode_jparam = json_decode(file_get_contents('php://input'), true);
					} catch (\Exception $exception) {
						// Ignore if you can not convert to JSON.
					}
				}

				if (strpos(strtolower($accept_header), 'charset=') === false) {
					header("Content-Type: $accept_header; charset=UTF-8");
				} else {
					header("Content-Type: $accept_header");
				}

				chdir(dirname($ajax_file));

				require $ajax_file;

				if (isset($jnode_dataset)) {
					echo is_array($jnode_dataset) ? json_encode($jnode_dataset) : $jnode_dataset;
				} else {
					// echo "{}";  // If the response is sent as a non-JSON format, comment it out so that it can be directly implemented in the $ajax_file.
				}
			} catch (\Error $e) {
				$this->displayAJAXException(500, $e->getMessage(), $e->getFile(), $e->getLine(), 256);
			} catch (\Exception $e) {
				$this->displayAJAXException(500, $e->getMessage(), $e->getFile(), $e->getLine(), (get_class($e) == 'ErrorException' ? $e->getSeverity() : 1024));
			}
		} else {
			$error_filename = $this->getErrorFile($ajax_file, false);
			$this->displayAJAXException(404, "There is no AJAX handler file (\"$error_filename\") for the request URI (\"{$_SERVER["REQUEST_URI"]}\").");
		}
	}

	/**
	 * This function escapes a string for use in HTML INPUT (including TEXTAREA).
	 *
	 * @param  $value  The string to be escaped.
	 * @return A string escaped for use in HTML INPUT (including TEXTAREA).
	 */
	public function escapeXML(string $value): string {
		if (empty($value))  return $value;

		return htmlspecialchars($value, ENT_QUOTES);
	}

	/**
	 * This function handles HTML escape to display target contents at body of HTML tag.
	 *
	 * You can set number of spaces for tab character,\t, at $tabindent, and the default number is 4.
	 * It is different from escapeXML function. That means it handles white space as escape.
	 *
	 * If $newline_tag is set to 'br' or 'BR', new line is converted into &lt;br&gt; tag.
	 * If $newline_tag is set to 'div' or 'DIV', new line is converted into the &lt;div&gt; tag.
	 * At this time, if the uppercase 'BR' or 'DIV' is set, a new line character (\n) is appended to the new line tag.
	 *
	 * @param  $value        The string to be escaped.
	 * @param  $tabindent    The number of spaces to convert the tab character (\t).
	 * @param  $newline_tag  HTML element tag to use for processing the new line (<B>'br'</B> | 'BR' | 'div' | 'DIV') (since 1.8).
	 * @return An escaped string that can be used in HTML.
	 */
	public function escapeHTML(string $value, int $tabindent = 4, string $newline_tag = 'br'): string {
		if (empty($value))  return $value;

		$replaced_tab = '';
		for ($i = 0; $i < $tabindent; $i++) {
			$replaced_tab .= ' ';
		}

		$value = htmlspecialchars($value, ENT_QUOTES);
		$value = str_replace("\t", $replaced_tab, $value);
		$value = preg_replace("/^ /m", "&nbsp;",  $value);
		$value = preg_replace("/ $/m", "&nbsp;",  $value);
		$value = str_replace("  ",     " &nbsp;", $value);
		$value = str_replace("\r\n",   "\n",      $value);

		if (strpos($value, "\n") === false) {
			return $value;
		} else {
			if (strtolower($newline_tag) == 'div') {
				$value = preg_replace("/\n\n/", "\n<br />\n", $value);
				$value = preg_replace("/\n\n/", "\n<br />\n", $value);
				$value = preg_replace("/^\n/",  "<br />\n",   $value);
				$value = preg_replace("/\n$/",  "\n<br />",   $value);

				if ($newline_tag == 'DIV') {
					$value = "<div>".preg_replace("/\n/", "</div>\n<div>", $value)."</div>";
				} else {
					$value = "<div>".preg_replace("/\n/", "</div><div>", $value)."</div>";
				}
			} else {
				$value = nl2br($value);

				if ($newline_tag == 'br') {
					$value = preg_replace("/<br(\s+[^<|>]*)?\/?>\n/i", '<br />', $value);
				}
			}
		}

		return $value;
	}

	/**
	 * This function creates an i18n JSON notation string for the date format to be used by the $module$.date.Formatter JavaScript object.
	 *
	 * If $notdefined_only is true, this function creates an i18n JSON notation string for the date format only
	 * for languages that are not defined in the $module$.date.Formatter JavaScript object.
	 *
	 * The intl module is used internally to generate the i18n JSON notation string for the date format.
	 * If the intl module is not installed, it ignores the user's configuration and is processed
	 * only in the language defined in the $module$.date.Formatter JavaScript object.
	 * Unspecified languages are processed in English.
	 *
	 * @param  $lang             Language code.
	 * @param  $notdefined_only  Whether to create only those languages that are not defined in the $module$.date.Formatter JavaScript object.
	 * @return i18n JSON notation string for the date format.
	 */
	public function getDateI18n(string $lang = 'en', bool $notdefined_only = true): string {
		if (strlen($lang) > 2)  $lang = substr($lang, 0, 2);

		if (extension_loaded('intl')) {
			if ($notdefined_only) {
				if ($lang == 'en' || $lang == 'ja' || $lang == 'ko' || $lang == 'zh') {
					return json_encode(['lang' => $lang]);
				}
			}

			$default_timezone = date_default_timezone_get();
			$GREGORIAN        = \IntlDateFormatter::GREGORIAN;

			$shortDateFmt  = new \IntlDateFormatter($lang, \IntlDateFormatter::SHORT,  \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN);
			$mediumDateFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::MEDIUM, \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN);
			$longDateFmt   = new \IntlDateFormatter($lang, \IntlDateFormatter::LONG,   \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN);
			$fullDateFmt   = new \IntlDateFormatter($lang, \IntlDateFormatter::FULL,   \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN);

			$shortTimeFmt  = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::SHORT,  $default_timezone, $GREGORIAN);
			$mediumTimeFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::MEDIUM, $default_timezone, $GREGORIAN);
			$longTimeFmt   = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::LONG,   $default_timezone, $GREGORIAN);
			$fullTimeFmt   = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::FULL,   $default_timezone, $GREGORIAN);

			// Month Names
			$shortMonthFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN, "MMM");
			$longMonthFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN, "MMMM");

			$MonthNames = array_map(
				function($m) use($shortMonthFmt){
					return $shortMonthFmt->format(mktime(0, 0, 0, $m, 2, 1970));
				},
				range(1, 12)
			);

			$MonthNames = array_merge($MonthNames, array_map(
				function($m) use($longMonthFmt){
					return $longMonthFmt->format(mktime(0, 0, 0, $m, 2, 1970));
				},
				range(1, 12)
			));

			// Week Names
			$shortWeekFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN, "EEE");
			$longWeekFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN, "EEEE");

			$WeekdayNames = array_map(
				function($m) use($shortWeekFmt){
					return $shortWeekFmt->format(mktime(0, 0, 0, 0, $m, 1970));
				},
				range(0, 6)
			);

			$WeekdayNames = array_merge($WeekdayNames, array_map(
				function($m) use($longWeekFmt){
					return $longWeekFmt->format(mktime(0, 0, 0, 0, $m, 1970));
				},
				range(0, 6)
			));

			// Ampm Names
			$ampmFmt = new \IntlDateFormatter($lang, \IntlDateFormatter::NONE, \IntlDateFormatter::NONE, $default_timezone, $GREGORIAN, "a");

			$AmpmNames = array_map(
				function($m) use($ampmFmt){
					return $ampmFmt->format(mktime($m * 12, 0, 0, 0, 0, 1970));
				},
				range(0, 1)
			);

			$date_i18n = [
				'Symbols' => [
					'MonthNames'   => $MonthNames,
					'WeekdayNames' => $WeekdayNames,
					'AmpmNames'    => $AmpmNames
				],
				'DateStyle' => [
					'SHORT'  => preg_replace("/\by{1}\b/", "yy"  , $shortDateFmt->getPattern()),
					'MEDIUM' => preg_replace("/\by{1}\b/", "yyyy", $mediumDateFmt->getPattern()),
					'LONG'   => preg_replace("/\by{1}\b/", "yyyy", $longDateFmt->getPattern()),
					'FULL'   => preg_replace("/\by{1}\b/", "yyyy", $fullDateFmt->getPattern())
				],
				'TimeStyle' => [
					'SHORT'  => $shortTimeFmt->getPattern(),
					'MEDIUM' => $mediumTimeFmt->getPattern(),
					'LONG'   => $longTimeFmt->getPattern(),
					'FULL'   => str_replace("zzzz", "z", $fullTimeFmt->getPattern())
				]
			];

			return json_encode($date_i18n);
		} else {
			if (!($lang == 'en' || $lang == 'ja' || $lang == 'ko' || $lang == 'zh')) {
				$lang = 'en';
			}

			return json_encode(['lang' => $lang]);
		}
	}

	/**
	 * This function fetches all the information contained in the HTTP request header as an associative array.
	 *
	 * If you install PHP as Apache http server module, you can use apache_request_headers() function,
	 * but it does not provide function to get HTTP request information if it is used in other web server like Nginx web server.
	 *
	 * If the getallheaders() function exists, which is an alias of apache_request_headers() function, this function use getallheaders() function.
	 * If the getallheaders() function does not exist, this function finds HTTP related information in $_SERVER
	 * and replaces it with header name format and provides information with an associative array.
	 *
	 * If $lower_case is true, all header names are lowercase.
	 *
	 * @param  $lower_case  Whether to include HTTP request header information in lower case names.
	 * @return An associative array containing the HTTP request header information.
	 */
	public function getRequestHeaders(bool $lower_case = false): array {
		if (function_exists('getallheaders')) {
			$headers = getallheaders();

			if ($lower_case) {
				$new_headers = [];

				foreach ($headers as $name => $value) {
					$new_headers[strtolower($name)] = $value;
				}

				return $new_headers;
			} else {
				return $headers;
			}
		} else {
			if (!is_array($_SERVER))  return array();

			$headers = array();
			foreach ($_SERVER as $name => $value) {
				if (substr($name, 0, 5) == 'HTTP_') {
					$key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
					if ($lower_case)  $key = strtolower($key);
					$headers[$key] = $value;
				}
			}

			return $headers;
		}
	}

	/**
	 * This function retrieves the header information corresponding to $name in the HTTP request header.
	 *
	 * If you install PHP as an Apache http server module, you can use the apache_request_headers() function,
	 * but it does not provide a function to get HTTP request header information if you use it with other web servers like Nginx web server.
	 *
	 * If the getallheaders() function exists, which is an alias of apache_request_headers() function,
	 * the header value is retrieved corresponding to $name with the getallheaders() function.
	 * If the getallheaders() function does not exist, the header value is retrieved corresponding to $name with the this->getRequestHeaders() function.
	 *
	 * @param  $name         HTTP request header name.
	 * @param  $ignore_case  Whether to ignore case and retrieve the HTTP request header name.
	 * @return HTTP request header value.
	 */
	public function getRequestHeader(string $name, bool $ignore_case = false): string {
		if ($ignore_case) {
			$requestHeader = $this->getRequestHeaders($ignore_case);
			$lower_name = strtolower($name);

			if (isset($requestHeader[$lower_name]))  return $requestHeader[$lower_name];
			else                                     return (string)null;
		} else {
			$requestHeader = $this->getRequestHeaders();

			if (isset($requestHeader[$name]))  return $requestHeader[$name];
			else                               return (string)null;
		}
	}


	/**
	 * This function fetches all the information contained in the HTTP response header as an associative array.
	 *
	 * If you install PHP as Apache http server module, you can use apache_response_headers() function,
	 * but it does not provide function to get HTTP response header information if it is used in other web server like Nginx web server.
	 *
	 * If the apache_response_headers() function exists, this function use apache_response_headers() function.
	 * If the apache_response_headers() function does not exist, this function fetches HTTP response header information with headers_list() function
	 * and provides information with an associative array.
	 *
	 * If $lower_case is true, all header names are lowercase.
	 *
	 * @param  $lower_case  Whether to include HTTP response header information in lower case names.
	 * @return An associative array containing the HTTP response header information.
	 * @since  Jnode Framework 1.9
	 */
	public function getResponseHeaders(bool $lower_case = false): array {
		if (function_exists('apache_response_headers')) {
			$headers = apache_response_headers();

			if ($lower_case) {
				$new_headers = [];

				foreach ($headers as $name => $value) {
					$new_headers[strtolower($name)] = $value;
				}

				return $new_headers;
			} else {
				return $headers;
			}
		} else {
			$headers = array();
			$header_name_values = headers_list();

			foreach ($header_name_values as $header_name_value) {
				$name_value = explode(":", $header_name_value);

				$name = trim($name_value[0]);
				if ($lower_case)  $name = strtolower($name);

				$headers[$name] = trim($name_value[1]);
			}

			return $headers;
		}
	}

	/**
	 * This function retrieves the header information corresponding to $name in the HTTP response header.
	 *
	 * If you install PHP as an Apache http server module, you can use the apache_response_headers() function,
	 * but it does not provide a function to get HTTP response header information if you use it with other web servers like Nginx web server.
	 *
	 * If the apache_response_headers() function exists,
	 * the header value is retrieved corresponding to $name with the apache_response_headers() function.
	 * If the apache_response_headers() function does not exist, the header value is retrieved corresponding to $name with the this->getResponseHeaders() function.
	 *
	 * @param  $name         HTTP response header name.
	 * @param  $ignore_case  Whether to ignore case and retrieve the HTTP response header name.
	 * @return HTTP response header value.
	 * @since  Jnode Framework 1.9
	 */
	public function getResponseHeader(string $name, bool $ignore_case = false): string {
		if ($ignore_case) {
			$responseHeader = $this->getResponseHeaders($ignore_case);
			$lower_name = strtolower($name);

			if (isset($responseHeader[$lower_name]))  return $responseHeader[$lower_name];
			else                                      return (string)null;
		} else {
			$responseHeader = $this->getResponseHeaders();

			if (isset($responseHeader[$name]))  return $responseHeader[$name];
			else                                return (string)null;
		}
	}

	/**
	 * This is a function to output an error message to the screen according to the status code when an error occurs at the requested page template file.
	 *
	 * In the ${web_domain_root}/protected_cgi/template/page/staus directory, the file with the .html extension to the status code is called.
	 *
	 * @param  $status_code    Error status code
	 * @param  $error_message  Error message
	 */
	public function sendError(int $status_code, string $error_message = null, int $errno = 1024) {
		$not_found_server_ajax = false;

		if (($status_code == 404) && preg_match($this::$AJAX_PATTERN, $_SERVER['REQUEST_URI'], $ajax_matcher)) {
			if (isset($ajax_matcher[1])) {
				$not_found_server_ajax = true;
			}
		}

		if ($not_found_server_ajax) {
			$this->displayAJAXException(404, 'To handle the AJAX request URI with Jnode Framweork, it must be set to "/jnode/lib/server/ajax.php" with rewrite.');
		} else {
			$severity_name = $this->getSeverityName($errno);

			if ($status_code == 500) {
				if (is_null($error_message))  $error_message = 'Internal Server Error';
				throw new \Exception($error_message);
			} else if (isset($error_message)) {
				$header_error_message = (isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0')." $status_code $error_message";
				error_log("$severity_name: $error_message");
				header($header_error_message, true, $status_code);
			} else {
				http_response_code($status_code);
			}
	
			$error_handling_file_id = $this::$TEMPLATE_PATH."/page/status/$status_code";
	
			if (file_exists("$error_handling_file_id.html")) {
				$jnode = $this;
	
				if (file_exists("$error_handling_file_id.php")) {
					require "$error_handling_file_id.php";
	
					if (isset($jnode_dataset)) {
						$dataset_id = str_replace('=', '', base64_encode(date("Y-m-d\TH:i:s")));
						setcookie('Jnode-Frontend-Id', $dataset_id, 0, '/');
	
						if(!isset($_SESSION))  session_start();
						$_SESSION[$dataset_id] = is_array($jnode_dataset) ? json_encode($jnode_dataset) : $jnode_dataset;
					}
				}
	
				require "$error_handling_file_id.html";
			} else {
				error_log("$severity_name: \"/template/page/status/$status_code.html\" file is not found.");
			}
		}

		exit;
	}

	/**
	 * This is a function to output an error message to the screen according to the status code
	 * when an error occurs at the requested node content template file.
	 *
	 * In the ${web_domain_root}/protected_cgi/template/content/staus directory,
	 * the file with the .ejs extension to the $node_type is called.
	 *
	 * Since the PHP Interpreter is responding to the front-end immediately when it is executed,
	 * if there is an error in the middle, an error handling template file will be added after the response has already been given.
	 * Therefore, a delimiter may be required to distinguish the error-handling Template file from the information already output before the error occurs.
	 * To facilitate maintenance, the +PHP Jnode Framework separates the file that processes the logic for the calling node ID from the file for the display output.
	 * At this time, the type of file processing logic is "php" and the file type for display output is "html". The type of file
	 * that handles the logic does not need to be an additional delimiter because it does not have any output on the screen, but it is needed when it is "html".
	 *
	 * @param  $node_type   Node content type requested.
	 * @param  $error_info  An associative array containing error information.
	 * @param  $file_type   The type of request file.
	 */
	public function sendContentError(string $node_type, array $error_info, string $file_type = 'html') {
		if (empty($error_info['request_uri']))  $error_info['request_uri'] = $_SERVER['REQUEST_URI'];

		$jnode_dataset = [
			'error' => $error_info
		];

		$status_template_file = $this::$TEMPLATE_PATH."/content/status/$node_type.ejs";

		if (!file_exists($status_template_file)) {
			$status_template_file = $this::$TEMPLATE_PATH.'/content/status/default.ejs';
			$jnode_dataset['status_file'] = 'default';
		}

		if (file_exists($status_template_file)) {
			$plain_delimiter = "Jnode-Response-Delimiter_".date("Y-m-d\TH:i:s");
			$delimiter = base64_encode($plain_delimiter);

			header("Jnode-Response-Delimiter: $delimiter");

			if ($file_type == 'html') {
				echo "\"\"''<-------- $delimiter -------->''\"\"";
			}

			echo json_encode($jnode_dataset);
			echo "\"\"''<-------- $delimiter -------->''\"\"";
			echo file_get_contents($status_template_file);

			// if (isset($jnode_dataset['error']['stack']))  error_log($jnode_dataset['error']['stack']);
		} else {
			$this->sendError($error_info['status_code']);
		}

		exit;
	}

	private function getIncludeFilename($filename_with_quot, $jnode_substitutor) {
		if (strpos($filename_with_quot, "'") === 0) {
			return substr($filename_with_quot, 1, - 1);
		} else {
			$filename_string = preg_replace("/\\$\{([^\}]+)\}/", "{\$jnode_substitutor['$1']}", $filename_with_quot);

			if ($filename_string === $filename_with_quot) {
				return substr($filename_with_quot, 1, - 1);
			} else {
				eval("\$include_filename = $filename_string;");
				return $include_filename;
			}
		}
	}

	private function getIncludeValue($template_file, $template_ext, $node_type, $jnode, $jnode_substitutor) {
		$template_value = file_get_contents($template_file);
		$match_count = preg_match_all("/[$]include[$]\s*\(\s*((\"[^\"|\n]*\")|('[^'|\n]*'))\s*\)/", $template_value, $matches, PREG_OFFSET_CAPTURE);

		if ($match_count > 0) {
			$container_dirname   = dirname($template_file);
			$include_pattern_map = [];
			$include_patterns    = [];
			$include_values      = [];

			for ($i = 0; $i < $match_count; $i++) {
				$matched_pattern = $matches[0][$i][0];

				// Ignore indent and check
				if (empty($include_pattern_map[$matched_pattern])) {
					$indent_value     = null;
					$matched_capture  = $matches[1][$i][0];
					$include_filename = $this->getIncludeFilename($matched_capture, $jnode_substitutor);

					$match_index  = $matches[0][$i][1];
					$indent_index = strrpos("\n".substr($template_value, 0, $match_index), "\n");

					if (substr($include_filename, 0, 1) == '/')  $include_filename = $jnode::$TEMPLATE_PATH."$include_filename.$template_ext";
					else                                         $include_filename = "$container_dirname/$include_filename.$template_ext";

					if (($indent_index > -1) && ($match_index > $indent_index)) {
						// Indent only for white space characters.
						$indent_value = substr($template_value, $indent_index, ($match_index - $indent_index ));
						if (!empty(trim($indent_value)))  $indent_value = null;
					}

					// Last check by considering indentation
					if (empty($indent_value) || empty($include_pattern_map[$indent_value.$matched_pattern])) {
						if (file_exists($include_filename)) {
							$include_value = $jnode->getIncludeValue($include_filename, $template_ext, $node_type, $jnode, $jnode_substitutor);

							if (isset($indent_value)) {
								$matched_pattern = $indent_value.$matched_pattern;
								$include_value   = $indent_value.str_replace("\n", "\n$indent_value", $include_value);
							}

							$include_pattern_map[$matched_pattern] = $include_filename;
							$include_patterns[] = $matched_pattern;
							$include_values[]   = $include_value;
						} else {
							$line_no = count(explode("\n", substr($template_value, 0, $match_index)));

							$error_filename   = null;
							$cgi_home_length  = strlen($jnode::$CGI_HOME);
							$html_home_length = strlen($jnode::$HTML_HOME);

							if (substr($template_file, 0, $cgi_home_length) == $jnode::$CGI_HOME) {
								$error_filename = substr($template_file, $cgi_home_length);
							} elseif (substr($template_file, 0, $html_home_length) == $jnode::$HTML_HOME) {
								$error_filename = substr($template_file, $html_home_length);
							} else {
								$error_filename = "file://$template_file";
							}

							if (isset($node_type)) {
								$jnode->sendContentError($node_type, [
									'status_code' => 500,
									'template'    =>'ejs',
									'message'     => "There is no template file for the ".trim($matched_pattern),
									'stack'       => "There is no template file for the ".trim($matched_pattern)."\n\tat $error_filename (Line:$line_no)",
									'fromBackend' => true
								]);
							} else {
								$jnode->sendError(500, "There is no template file for the ".trim($matched_pattern)." at $error_filename (Line:$line_no)");
							}
						}
					}
				}
			}

			$template_value = str_replace($include_patterns, $include_values, $template_value);
		}

		return $template_value;
	}

	private function requireRecursive($file_name) {
		if (substr($file_name, -2) == '/*') {
			$dir_name = substr($file_name, 0, -2);
			$files = array_diff(scandir($dir_name), ['.', '..']);

			foreach ($files as $file) {
				$sub_file_name = "$dir_name/$file";
				if (is_dir($sub_file_name)) {
					$this->requireRecursive("$sub_file_name/*");
				} else {
					$extension = strtolower(pathinfo($sub_file_name)['extension']);

					// if (array_search($extension, ['php']) !== false) {
					if ($extension == 'php') {
						require_once $sub_file_name;
					}
				}
			}
		} elseif (file_exists($file_name)) {
			require_once $file_name;
		}
	}

	/**
	 * This function handles exception that occurs when executing contenent request such as page or element node.
	 *
	 * @param  $severity  Exception serverity.
	 * @param  $message   Exception message.
	 * @param  $filename  The name of the file where the exception occurred.
	 * @param  $lineno    The line number of the file where the exception occurred.
	 */
	public function handleContentException(int $severity = 1024, string $message, string $filename, int $lineno) {
		if (error_reporting() == 0) {
			return;
		} elseif ($severity) {
			$this->displayContentException($message, $filename, $lineno, $severity);
		}
	}

	/**
	 * This function handles exception that occurs when executing AJAX request.
	 *
	 * @param  $severity  Exception serverity.
	 * @param  $message   Exception message.
	 * @param  $filename  The name of the file where the exception occurred.
	 * @param  $lineno    The line number of the file where the exception occurred.
	 */
	public function handleAJAXException(int $severity = 1024, string $message, string $filename = null, int $lineno = -1) {
		if (error_reporting() == 0) {
			return;
		} elseif ($severity) {
			$this->displayAJAXException(500, $message, $filename, $lineno, $severity);
		}
	}

	private function displayContentException($message, $filename, $lineno, int $errno = 1024) {
		$severity_name = $this->getSeverityName($errno);

		$is_page = (empty($_POST['nodeType']) || empty($_POST['requireType']) || empty($_POST['nodeType']));
		$jnode_error = [
			'status_code' => 500,
			'message'     => $message
		];

		$error_filename = $this->getErrorFile($filename, $is_page);

		if ($error_filename == '/lib/Jnode.Framework.php') {
			$jnode_error['stack'] = $message;
			error_log("$severity_name: $message");
		} else {
			$jnode_error['stack'] = "$message\n\tat $error_filename (Line:$lineno)";
			error_log("$severity_name: $message in $filename on line $lineno");
		}

		if ($is_page) {
			$jnode_error['request_uri'] = $_SERVER['REQUEST_URI'];

			$jnode = $this;
			require $this::$TEMPLATE_PATH.'/page/status/500.html';
			exit;
		} else {
			$jnode_error['template']    = 'ejs';
			$jnode_error['fromBackend'] = true;
			$jnode_error['request_uri'] = $error_filename;

			$file_type = strtolower(pathinfo($error_filename)['extension']);
			if ($file_type != 'php')  $file_type == 'html';

			$this->sendContentError($_POST['nodeType'], $jnode_error, $file_type);
		}
	}

	private function displayAJAXException($statuscode, $message, $filename = null, $lineno = -1, int $errno = 1024) {
		http_response_code($statuscode);

		$severity_name = $this->getSeverityName($errno);

		// throw new \Exception($message);
		$error_filename = $this->getErrorFile($filename);
		$jnode_error = [
			'status_code' => $statuscode,
			'message'     => $message
		];

		if ($lineno == -1) {
			$jnode_error['stack'] = $message;
		} else {
			$jnode_error['stack'] = "$message\n\tat $error_filename (Line:$lineno)";
		}

		error_log("$severity_name: ".$jnode_error['message'].($lineno == -1 ? '' : " in $filename on line $lineno"));
		echo json_encode($jnode_error);
		exit;
	}

	private function getErrorFile($filename, $is_page = false) {
		$error_filename   = null;
		$cgi_home_length  = strlen($this::$CGI_HOME);

		if ($is_page) {
			$page_path = $this::$TEMPLATE_PATH.($this::$COLLAPSE_SCOPE == 'template' ? '/collapse' : '/page');
			$page_path_length = strlen($page_path);

			if (substr($filename, 0, $page_path_length) == $page_path) {
				$error_filename = substr($filename, $page_path_length);
			} elseif (substr($filename, 0, $cgi_home_length) == $this::$CGI_HOME) {
				$error_filename = substr($filename, $cgi_home_length);
			} else {
				$error_filename = "file://$filename";
			}
		} else {
			$html_home_length = strlen($this::$HTML_HOME);

			if (substr($filename, 0, $cgi_home_length) == $this::$CGI_HOME) {
				$error_filename = substr($filename, $cgi_home_length);
			} elseif (substr($filename, 0, $html_home_length) == $this::$HTML_HOME) {
				$error_filename = substr($filename, $html_home_length);
			} else {
				$error_filename = "file://$filename";
			}
		}

		return $error_filename;
	}

	private function getSeverityName($severity) {
		$severity_name = 'Jnode Unknown Error';

		switch ($severity) {
			case E_USER_ERROR:
				$severity_name = 'Jnode Fatal Error';
			break;
			case E_USER_WARNING:
			case E_WARNING:
				$severity_name = 'Jnode Warning';
			break;
			case E_USER_NOTICE:
			case E_NOTICE:
			case @E_STRICT:
				$severity_name = 'Jnode Notice';
			break;
			case @E_RECOVERABLE_ERROR:
				$severity_name = 'Jnode Catchable';
			break;
		}

		return $severity_name;
	}
}

(function() {
	Jnode::$HTML_HOME     = $_SERVER['DOCUMENT_ROOT'];
	Jnode::$CGI_HOME      = dirname(__DIR__);
	Jnode::$MOD_PATH      = join(DIRECTORY_SEPARATOR, [Jnode::$CGI_HOME, 'lib', 'mods']);
	Jnode::$TEMPLATE_PATH = join(DIRECTORY_SEPARATOR, [Jnode::$CGI_HOME, 'template']);

	$json_selector = join(DIRECTORY_SEPARATOR, [__DIR__, 'conf', 'jnode.selector.json']);

	if (file_exists($json_selector)) {
		$json_string = file_get_contents($json_selector);
		# NOTE: Disable bug bypassing that can not be decoded if there is a comment.
		# $json_string = preg_replace("#(/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/)|([\s\t]//.*)|(^//.*)#", '', $json_string);
		$options = json_decode($json_string, true);

		if (empty($options)) {
			error_log('Jnode Notice: The settings of "/lib/conf/jnode.selector.json" file is ignored, because the file is empty or invalid JSON format.');
		} else {
			foreach ($options as $option => $value) {
				Jnode::${strtoupper($option)} = $value;
			}
		}
	}
})();