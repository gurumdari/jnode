/*
 * @(#)TemplateResolver.java  1.9, 2018-09-28
 */
package com.jnodeframework.resolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.text.StringSubstitutor;

import com.gurumdari.CommandBridge;
import com.jnodeframework.util.RequestUtil;

/**
 * Class to resolve template file.
 * 
 * @version 1.0, 2014-10-10
 * @version 1.2, 2015-03-03  Providing availability of using JavaScript template engine in layout page
 * @version 1.6, 2016-02-02  Providing management function by path of the node ID without classifying the node type, Providing converting function of Java Map Object as JSON
 * @version 1.7, 2017-04-04  Providing template files implementation function by each language locale
 * @version 1.9, 2018-09-28  Replaced the Gson with the javax.json library (JSON Processing API).
 * @author  Jeasu Kim
 */
public class TemplateResolver {
	private HttpServletRequest  request     = null;
	private HttpServletResponse response    = null;
	private ServletContext      context     = null;
	private RequestUtil         requestUtil = null;
	private String templatePath  = null;
	private String collapseScope = null;
	private String templateType  = null;
	private String templateExt   = null;
	private String blang         = null;
	private Map<String, Object> bindingData = null;

	/**
	 * Template Resolver constructor.
	 * 
	 * @param  request   Client request object.
	 * @param  response  Server response object.
	 */
	public TemplateResolver(HttpServletRequest request, HttpServletResponse response) {
		requestUtil = new RequestUtil(request);

		this.request  = request;
		this.response = response;
		this.context  = request.getServletContext();
		this.templatePath  = requestUtil.getTemplatePath();
		this.collapseScope = requestUtil.getCollapseScope();
		this.blang         = request.getParameter("blang");

		String template = request.getParameter("template");

		if (template == null) {
			this.templateType = "ejs";
			this.templateExt  = ".ejs";
		} else {
			String[] separatedTemplates = template.split("\\.");

			if (separatedTemplates.length == 1) {
				this.templateType = template;

				if (template.equals("html"))  this.templateExt = ".jsp";
				else                          this.templateExt = "." + template;
			} else {
				this.templateType = separatedTemplates[0];
				this.templateExt  = "." + separatedTemplates[1];
			}
		}
	}

	/**
	 * Template Resolver constructor.
	 * 
	 * If the template type and extension are different in the template parameter, you can use a dot (.) as a delimiter and connect template type and extension.
	 * However, in case of html template type, the default extension is jsp, not html.
	 * 
	 * @param  request   Client request object.
	 * @param  response  Server response object.
	 * @param  template  Template information.
	 */
	public TemplateResolver(HttpServletRequest request, HttpServletResponse response, String template) {
		requestUtil   = new RequestUtil(request);

		this.request  = request;
		this.response = response;
		this.context  = request.getServletContext();
		this.templatePath  = requestUtil.getTemplatePath();
		this.collapseScope = requestUtil.getCollapseScope();
		this.blang         = request.getParameter("blang");

		if (template == null)  template = request.getParameter("template");

		if (template == null) {
			this.templateType = "ejs";
			this.templateExt  = ".ejs";
		} else {
			String[] separatedTemplates = template.split("\\.");

			if (separatedTemplates.length == 1) {
				this.templateType = template;

				if (template.equals("html"))  this.templateExt  = ".jsp";
				else                          this.templateExt  = "." + template;
			} else {
				this.templateType = separatedTemplates[0];
				this.templateExt  = "." + separatedTemplates[1];
			}
		}
	}

	/**
	 * This method retrieves the range that does not distinguish the template path.
	 * 
	 * <UL>
	 *   <LI><CODE>none</CODE> - By default, content is managed by the directory corresponding to the node type in the <CODE>content</CODE> directory that distinguishes content by node type.</LI>
	 *   <LI><CODE>content</CODE> - Content is not distinguished by node type in the <CODE>collapse</CODE> directory.</LI>
	 *   <LI><CODE>template</CODE> - Content is not distinguished by node type, and page also is not distinguished in the <CODE>collapse</CODE> directory.</LI>
	 * </UL>
	 * 
	 * @return cope of collapsed template path.
	 * @since  1.6
	 */
	public String getCollapseScope() {
		return requestUtil.getCollapseScope();
	}

	/**
	 * This method gets the template type.
	 * 
	 * If not specified, ejs is returned.
	 * 
	 * @return  Template type.
	 */
	public String getTemplateType() {
		return this.templateType;
	}

	/**
	 * This method gets the template extension.
	 * 
	 * If the extension is not specified, the same value as the template type is returned. However, jsp is returned if the template type is html.
	 * 
	 * @return  Template extension.
	 */
	public String getTemplateExt() {
		return this.templateExt.substring(1);
	}

	/**
	 * This method retrieves the contents of the template file that is read.
	 * 
	 * This method retrieves the final value that was included in the nesting through Jnode Include.
	 * 
	 * This method retrieves the template file for the language corresponding to the blang.
	 * At this time, if there is no template file of the corresponding language,
	 * the basic file which is not designated as a language is retrieved.
	 * 
	 * @param  templateId  template file name without extension.
	 * @param  encoding    The character set.
	 * @param  blang       The language code.
	 * @return The contents of the template file.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.7
	 */
	public String getTemplateValue(String templateId, String encoding, String blang) throws IOException {
		String langSubfix = "";

		if (request.getParameter("error.status_code") == null && blang != null) {
			langSubfix = "_" + blang;
		}

		String templateValue = null;

		try {
			templateValue = getTemplateValue(templateId + langSubfix, encoding);
		} catch(NullPointerException e) {
			templateValue = getTemplateValue(templateId, encoding);
		}

		return templateValue;
	}

	/**
	 * This method retrieves the contents of the template file that is read.
	 * 
	 * This method retrieves the final value that was included in the nesting through Jnode Include.
	 * 
	 * @param  templateId  template file name without extension.
	 * @param  encoding    The character set.
	 * @return The contents of the template file.
	 * @throws IOException  When the template file can not be read.
	 */
	public String getTemplateValue(String templateId, String encoding) throws IOException {
		String containerDirname = templateId.substring(0, templateId.lastIndexOf("/") + 1);

		String value = IOUtils.toString(context.getResourceAsStream(templatePath + templateId + templateExt), encoding);

		Map<String, String> includePatternMap = new HashMap<String, String>();

		Matcher matcher = Pattern.compile("\\$include\\$\\s*\\(\\s*((\"[^\"|\\n]*\")|('[^'|\\n]*'))\\s*\\)").matcher(value);

		while(matcher.find()) {
			String matchedPattern  = matcher.group();

			// Ignore indent and check
			if (includePatternMap.get(matchedPattern) == null) {
				String indentValue     = null;
				String matchedCapture  = matcher.group(1);
				String includeFilename = getIncludeFilename(matchedCapture);

				int matchIndex  = matcher.start();
				int indentIndex = ("\n" + value).lastIndexOf("\n", matchIndex + 1);

				if (!includeFilename.startsWith("/"))  includeFilename = containerDirname + includeFilename;

				if (indentIndex > -1 && (matchIndex > indentIndex)) {
					// Indent only for white space characters.
					indentValue = value.substring(indentIndex, matchIndex);
					if (!"".equals(indentValue.trim()))  indentValue = null;
				}

				// Last check by considering indentation
				try {
					if (indentValue == null || includePatternMap.get(indentValue + matchedPattern) == null) {
						String includeValue = getTemplateValue(includeFilename, encoding);

						if (indentValue != null) {
							matchedPattern = indentValue + matchedPattern;
							includeValue   = indentValue + includeValue.replaceAll("\n", "\n" + indentValue);
						}

						includePatternMap.put(matchedPattern, includeValue);
					}
				} catch(NullPointerException e) {
					int lineNo = value.substring(0, matchIndex).split("\n", -1).length;
					throw new RuntimeException("There is no template file for the " + matchedPattern.trim() + "\n\tat " + this.templatePath + templateId + templateExt + " (Line:" + lineNo + ")");
				}
			}
		}

		Set<String> includePatternSet = includePatternMap.keySet();

		for (String includePattern : includePatternSet) {
			try {
				value = value.replaceAll("\\Q" + includePattern + "\\E", includePatternMap.get(includePattern));
			} catch (IllegalArgumentException e) {
				value = value.replace(includePattern, includePatternMap.get(includePattern));
			}
		}

		return value;
	}

	private String getIncludeFilename(String filenameWithQuot) {
		String includeFilename = filenameWithQuot.substring(1, filenameWithQuot.length() - 1);

		if (filenameWithQuot.startsWith("'")) {
			return includeFilename;
		} else {
			if (bindingData == null)  bindingData = requestUtil.getFormParam();

			return new StringSubstitutor(bindingData, "${", "}").replace(includeFilename);
		}
	}

	/**
	 * This method converts the parameters from the HttpServletRequest containing the parameters of the form data type into a Map object.
	 * 
	 * @return The Map object that is converted from the parameters requested by the Client.
	 */
	public <T> Map<String, T> getFormParam() {
		return requestUtil.getFormParam();
	}

	/**
	 * This method gets the path that manages the template files.
	 * 
	 * @return The path to manage the template files.
	 */
	public String getTemplatePath() {
		return requestUtil.getTemplatePath();
	}

	/**
	 * This method gets the ID for the template file requested by the front-end.
	 * 
	 * The template file requested in the front-end is used as content of the node or page.
	 * If jnode.collapseScope is not set, template ID is the same as /content/${nodeType}${nodeId} or /page${uri_without_context_ext}, respectively.
	 * If jnode.collapseScope is set to content, Only /collapse${nodeId} for the content of the node.
	 * If you set jnode.collapseScope to template, In all cases, template ID starts with /collapse,
	 * and the content of the node or page becomes /collapse${nodeId} or /collapse${uri_without_context_ext}, respectively.
	 * 
	 * ${uri_without_context_ext} means a URI excluding the context path and the extension.
	 * 
	 * @return Template ID.
	 */
	public String getTemplateId() {
		return requestUtil.getTemplateId();
	}

	/**
	 * This method retrieves the template ID that is processed when the template file requested by the front-end for use as a page is in not state code 200.
	 * 
	 * @param  statusCode  Status code.
	 * @return Template ID according to status code.
	 */
	public String getTemplateId(int statusCode) {
		return requestUtil.getTemplateId(statusCode);
	}

	/**
	 * When searching for a Page ID, this method prevents a mistake as a extension after the dot(.),
	 * if there is a dot(.) after the last slash(/) of the Page path.
	 * 
	 * @param  extensionWithDot  Extension with a dot(.).
	 * @since  1.9
	 */
	public void setPageExtension(String extensionWithDot) {
		requestUtil.setPageExtension(extensionWithDot);
	}

	/**
	 * This method retrieves the Page ID for the template file requested by front-end for use as page.
	 * 
	 * Page ID is the same as URI excluding the context path and the extension.
	 * 
	 * @return Page ID.
	 */
	public String getPageId() {
		return requestUtil.getPageId();
	}

	/**
	 * This method retrieves the Page ID for template file corresponding to requestURI including context path.
	 * 
	 * This method retrieves the Page ID by excluding the context path and its extension in requestURI.
	 * If requestURI does not have an extension, it is assumed to be a directory, and the index file in that directory is used.
	 * 
	 * @param  requestURI  A URI that contains the context path.
	 * @return Page ID.
	 */
	public String getPageId(String requestURI) {
		return requestUtil.getPageId(requestURI);
	}

	/**
	 * This method retrieves the page ID that is processed when the template file requested by the front-end for use as a page is in not state code 200.
	 * 
	 * @param  statusCode  Status code.
	 * @return Page ID based on status code
	 */
	public String getPageId(int statusCode) {
		return requestUtil.getPageId(statusCode);
	}

	/**
	 * This method retrieves the status code of page.
	 * 
	 * @return The status code of page.
	 */
	public int getPageStatusCode() {
		return requestUtil.getPageStatusCode();
	}

	/**
	 * This method parses the requestURI including the context path to get the page status code.
	 * 
	 * If you do not use error handling in the Jnode Framework, you can get an incorrect value.
	 * 
	 * @param  requestURI  A URI that contains the context path.
	 * @return The status code of page.
	 */
	public int getPageStatusCode(String requestURI) {
		return requestUtil.getPageStatusCode(requestURI);
	}

	/**
	 * This method retrieves the node content ID for the template file requested by the front-end for use as the content of the node.
	 * 
	 * If jnode.collapseScope is not set, it is the same as /${nodeType}${nodeId}.
	 * If jnode.collapseScope does not distinguish by node type, it is the same as ${nodeId}.
	 * 
	 * @return Content ID.
	 */
	public String getContentId() {
		return requestUtil.getContentId();
	}

	/**
	 * This function forwards the node content to the nodeId.
	 * 
	 * @param  nodeId  Node ID to be forwarded to
	 * @since  1.9
	 */
	public void forwardContent(String nodeId) {
		forwardContent(nodeId, false);
	}

	/**
	 * This function forwards the node content to the nodeId.
	 * 
	 * @param  nodeId          Node ID to be forwarded to
	 * @param  reloadRenderer  Whether to reload the Stylesheet and Script files corresponding to nodeId
	 * @since  1.9
	 */
	public void forwardContent(String nodeId, boolean reloadRenderer) {
		request.setAttribute("forward_node_id", nodeId);

		if (reloadRenderer)  response.addHeader("Jnode-Forward-Node-Id", nodeId);
	}

	/**
	 * This method retrieves a RequestDispatcher object that outputs a template file according to the HTTP status code.
	 * 
	 * @param  statusCode  HTTP status code.
	 * @return A RequestDispatcher object that outputs a template file according to the HTTP status code.
	 */
	public RequestDispatcher getDispatcher(int statusCode) {
		return requestUtil.getDispatcher(statusCode);
	}

	/**
	 * This method retrieves a RequestDispatcher object that outputs a template file corresponding to the template ID.
	 * 
	 * @param  templateId  Template ID.
	 * @return A RequestDispatcher object that outputs a template file corresponding to the template ID.
	 */
	public RequestDispatcher getDispatcher(String templateId) {
		return requestUtil.getDispatcher(templateId);
	}

	/**
	 * This method retrieves a RequestDispatcher object that outputs a template file for the node content corresponding to the nodeType and nodeId.
	 * 
	 * @param  nodeType  Node Type.
	 * @param  nodeId    Node ID.
	 * @return A RequestDispatcher object that outputs a template file for the node content corresponding to the nodeType and nodeId.
	 */
	public RequestDispatcher getDispatcher(String nodeType, String nodeId) {
		return requestUtil.getDispatcher(nodeType, nodeId);
	}

	/**
	 * This method converts a JSON notation string containing an array into a List object.
	 * 
	 * @param  listJson  The JSON notation string containing the array.
	 * @param  type      Type to reflect as a Java object.
	 * @return A List object that converts the array notation string.
	 * @deprecated As of version 1.7, removed from version 2.0
	 */
	public List<?> getJsonList(String listJson, Type type) {
		return requestUtil.getJsonList(listJson, type);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @deprecated As of version 1.9, replaced by {@link #renderPage()}, removed from version 2.0
	 */
	public void renderTemplate() throws IOException, ServletException {
		renderPage();
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  optionmap  Java Map object to use for rendering the template file.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.6
	 * @deprecated As of version 1.9, replaced by {@link #renderPage(Map)}, removed from version 2.0
	 */
	public void renderTemplate(Map<String, ?> optionmap) throws IOException, ServletException {
		renderPage(optionmap);
	}

	/**
	 * This method renders the template file to the engine corresponding to the template Type.
	 * 
	 * @param  optionmap  Java Map object to use for rendering the template file.
	 * @param  encoding   The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.6
	 * @deprecated As of version 1.9, replaced by {@link #renderPage(Map, String)}, removed from version 2.0
	 */
	public void renderTemplate(Map<String, ?> optionmap, String encoding) throws IOException, ServletException {
		renderPage(optionmap, encoding);
	}

	/**
	 * This method renders the template file to the engine corresponding to the template Type.
	 * 
	 * @param  optionmap       Java Map object to use for rendering the template file.
	 * @param  encoding        The character set. If null, it is recognized as a UTF-8 character set.
	 * @param  templatePrefix  The prefix path for template ID.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.6
	 * @deprecated As of version 1.9, replaced by {@link #renderPage(Map, String, String)}, removed from version 2.0
	 */
	public void renderTemplate(Map<String, ?> optionmap, String encoding, String templatePrefix) throws IOException, ServletException {
		renderPage(optionmap, encoding, templatePrefix);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  options  JSON notation string to use for rendering the template file.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @deprecated As of version 1.9, replaced by {@link #renderPage(String)}, removed from version 2.0
	 */
	public void renderTemplate(String options) throws IOException, ServletException {
		renderPage(options);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  options   JSON notation string to use for rendering the template file.
	 * @param  encoding  The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @deprecated As of version 1.9, replaced by {@link #renderPage(String, String)}, removed from version 2.0
	 */
	public void renderTemplate(String options, String encoding) throws IOException, ServletException {
		renderPage(options, encoding);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  options         JSON notation string to use for rendering the template file.
	 * @param  encoding        The character set. If null, it is recognized as a UTF-8 character set.
	 * @param  templatePrefix  The prefix path for template ID.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @deprecated As of version 1.9, replaced by {@link #renderPage(String, String, String)}, removed from version 2.0
	 */
	public void renderTemplate(String options, String encoding, String templatePrefix) throws IOException, ServletException {
		renderPage(options, encoding, templatePrefix);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage() throws IOException, ServletException {
		renderPage((String)null);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  optionmap  Java Map object to use for rendering the template file.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage(Map<String, ?> optionmap) throws IOException, ServletException {
		renderPage(optionmap, null);
	}

	/**
	 * This method renders the template file to the engine corresponding to the template Type.
	 * 
	 * @param  optionmap  Java Map object to use for rendering the template file.
	 * @param  encoding   The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage(Map<String, ?> optionmap, String encoding) throws IOException, ServletException {
		renderPage(optionmap, encoding, (collapseScope.equals("template") ? "/collapse" : "/page"));
	}

	/**
	 * This method renders the template file to the engine corresponding to the template Type.
	 * 
	 * @param  optionmap       Java Map object to use for rendering the template file.
	 * @param  encoding        The character set. If null, it is recognized as a UTF-8 character set.
	 * @param  templatePrefix  The prefix path for template ID.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage(Map<String, ?> optionmap, String encoding, String templatePrefix) throws IOException, ServletException {
		setBindingData(optionmap);
		renderPage(new CommandBridge().toJson(optionmap), encoding, templatePrefix);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  options  JSON notation string to use for rendering the template file.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage(String options) throws IOException, ServletException {
		renderPage(options, null);
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  options   JSON notation string to use for rendering the template file.
	 * @param  encoding  The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage(String options, String encoding) throws IOException, ServletException {
		renderPage(options, encoding, (collapseScope.equals("template") ? "/collapse" : "/page"));
	}

	/**
	 * This method renders the template file with an UTF-8 character set to the engine corresponding to the template Type.
	 * 
	 * @param  options         JSON notation string to use for rendering the template file.
	 * @param  encoding        The character set. If null, it is recognized as a UTF-8 character set.
	 * @param  templatePrefix  The prefix path for template ID.
	 * @throws IOException       When the template file can not be read or precompiled value can not be saved.
	 * @throws ServletException  When the request can not be forwarded to a JSP template file.
	 * @since  1.9
	 */
	public void renderPage(String options, String encoding, String templatePrefix) throws IOException, ServletException {
		if (encoding == null)  encoding = "UTF-8";

		if (options == null) {
			options = "{}";
		} else {
			String datasetId = new String(Base64.getEncoder().encodeToString(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date()).getBytes(encoding))).replaceAll("=", "");
			Cookie cookie = new Cookie("Jnode-Frontend-Id", datasetId);
			cookie.setPath("/");
			response.addCookie(cookie);

			Map<String, String> dataset = new HashMap<String, String>();
			dataset.put("options" , options);
			dataset.put("encoding", encoding);

			HttpSession session = request.getSession();
			session.setAttribute(datasetId, dataset);
		}

		String extensionWithDot = templateExt;
		if (extensionWithDot.equals(".jsp")) {
			extensionWithDot = "." + templateType;
		}

		requestUtil.setPageExtension(extensionWithDot);
		String templateId = templatePrefix + requestUtil.getPageId();

		try {
			if (templateType.equalsIgnoreCase("html")) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(templatePath + templateId + templateExt);
				dispatcher.forward(request, response);
			} else {
				String strPrecompile    = request.getServletContext().getInitParameter("jnode.precompile");
				String compiledValue    = null;
				String sourceFileName   = templatePath + templateId + templateExt;
				String compiledFileName = templatePath + "/precompile" + templateId + templateExt;
				File   compiledFile     = null;

				boolean precompile  = false;
				boolean existParent = false;
				boolean existFile   = false;
	
				if (options.equals("{}")) {
					if (strPrecompile != null)  precompile = Boolean.parseBoolean(strPrecompile);
				}

				if (precompile) {
					File sourceFile = new File(context.getRealPath(sourceFileName));
					compiledFile = new File(context.getRealPath(compiledFileName));

					existFile = compiledFile.exists();

					if (existFile && (sourceFile.lastModified() < compiledFile.lastModified())) {
						try {
							compiledValue = IOUtils.toString(context.getResourceAsStream(compiledFileName), encoding);
						} catch (NullPointerException e) {
						}
					} else {
						File parentDir = compiledFile.getParentFile();

						if (parentDir.exists() || makeDirectory(parentDir)) {
							existParent = true;
						} else {
							System.out.println("mkdir(): Permission denied during making directory \"" + parentDir.getCanonicalPath() + "\" for precompile.");
						}
					}
				}

				if (compiledValue == null) {
					String strJavaVersion = System.getProperty("java.version").split("_")[0];
					String[] javaVersions = strJavaVersion.split("\\.");
					float javaVersion = Float.parseFloat(javaVersions[0] + "." + javaVersions[1]);

					if (javaVersion > 1.7) {
						String jsExec = request.getServletContext().getInitParameter("jnode.jsExec");
						String enginePath = context.getRealPath("/WEB-INF/lib/template/");
						if (!enginePath.endsWith("/"))  enginePath = enginePath + "/";

						Map<String, String> serverMap = new HashMap<String, String>();
						serverMap.put("version"      , "1.9");
						serverMap.put("enginePath"   , enginePath);
						serverMap.put("contextPath"  , request.getContextPath());
						serverMap.put("templatePath" , templatePath);
						serverMap.put("templateType" , templateType);
						serverMap.put("templateExt"  , getTemplateExt());
						serverMap.put("collapseScope", collapseScope);

						Map<String, Object> serverOptions = new HashMap<String, Object>();
						serverOptions.put("server", serverMap);

						String value = getTemplateValue(templateId, encoding);

						try {
							if (jsExec == null || jsExec.equals("")) {
								ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");  // "nashorn"
								engine.eval(String.format("var server_options=%s", new CommandBridge().toJson(serverOptions)));
								engine.eval(IOUtils.toString(context.getResourceAsStream("/WEB-INF/lib/template/nashorn.js"), "UTF-8"));

								Invocable invocable = (Invocable)engine;
								compiledValue = (String)invocable.invokeFunction("renderPage", value, options);
							} else {
								serverOptions.put("value"  , value);
								serverOptions.put("options", options);

								String[] commands = {
									jsExec,
									enginePath + templateType + ".js"
								};

								String argSep = null;
								String jsExecWoExt = jsExec.toLowerCase();
								if (jsExecWoExt.endsWith(".exe"))  jsExecWoExt = jsExecWoExt.substring(0, jsExecWoExt.length() - 4);
								if (jsExecWoExt.endsWith("jjs") )  argSep = "--";

								compiledValue = new CommandBridge().call(commands, serverOptions, argSep);
							}

							if (existParent) {
								if (existFile || compiledFile.createNewFile()) {
									IOUtils.write(compiledValue, new FileOutputStream(compiledFile), encoding);
								} else {
									System.out.println("Permission denied during create file \"" + compiledFile.getCanonicalPath() + "\" for precompile.");
								}
							}
						} catch(ScriptException e) {
							throw new RuntimeException(e.getMessage());
						} catch(NoSuchMethodException e) {
							throw new RuntimeException(e.getMessage());
						}
					} else {
						throw new RuntimeException("Not support JavaScript-based template file in Java 7 or lower version");
					}
				}

				response.setContentType("text/html; charset=" + encoding);
				PrintWriter out = response.getWriter();
				out.print(compiledValue);
			}
		} catch(NullPointerException e) {
			RequestDispatcher dispatcher = requestUtil.getDispatcher(404);
			dispatcher.forward(request, response);
		}
	}

	/**
	 * This method resolves the template file with UTF-8 character set.
	 * 
	 * @throws IOException  When the template file can not be read.
	 * @deprecated As of version 1.9, replaced by {@link #resolveContent()}, removed from version 2.0
	 */
	public void resolveTemplate() throws IOException {
		resolveContent();
	}

	/**
	 * This method resolves the template file with UTF-8 character set and bind the JSON notation string that is converted Java Map object.
	 * 
	 * In the case of JavaScript-based template file, since it is rendered in the front-end,
	 * you need to convert the Java value oject used in the back-end into a JSON Object used in JavaScript.
	 * If you use Map Object with Java value oject, it automatically converts to JSON notation string and goes down to the front-end.
	 * 
	 * In the case of JSP, since it is rendered in the back-end, you can not use the JSON notation string data used in the front-end.
	 * Therefore, in the case of back-end-based template engine like JSP, before you convert the Java value oject to be passed to the front-end into a JSON notation string,
	 * you need the logic to set the Java value object in the attribute of the HttpServletRequest object in advance.
	 * Using Java Map Object data as a parameter, this series of operations is also done automatically.
	 * 
	 * @param  datamap  The Java Map object to be bound with template file.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.6
	 * @deprecated As of version 1.9, replaced by {@link #resolveContent(Map)}, removed from version 2.0
	 */
	public void resolveTemplate(Map<String, ?> datamap) throws IOException {
		resolveContent(datamap);
	}

	/**
	 * This method resolves the template file and bind the JSON notation string that is converted Java Map object.
	 * 
	 * In the case of JavaScript-based template file, since it is rendered in the front-end,
	 * you need to convert the Java value oject used in the back-end into a JSON Object used in JavaScript.
	 * If you use Map Object with Java value oject, it automatically converts to JSON notation string and goes down to the front-end.
	 * 
	 * In the case of JSP, since it is rendered in the back-end, you can not use the JSON notation string data used in the front-end.
	 * Therefore, in the case of back-end-based template engine like JSP, before you convert the Java value oject to be passed to the front-end into a JSON notation string,
	 * you need the logic to set the Java value object in the attribute of the HttpServletRequest object in advance.
	 * Using Java Map Object data as a parameter, this series of operations is also done automatically.
	 * 
	 * @param  datamap   The Java Map object to be bound with template file.
	 * @param  encoding  The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.6
	 * @deprecated As of version 1.9, replaced by {@link #resolveContent(Map, String)}, removed from version 2.0
	 */
	public void resolveTemplate(Map<String, ?> datamap, String encoding) throws IOException {
		resolveContent(datamap, encoding);
	}

	/**
	 * This method resolves the template file with UTF-8 character set and bind the JSON notation string.
	 * 
	 * In the case of JavaScript-based template file, only the template file is searched in the back-end, and the rendering is performed in the front-end.
	 * Therefore, the dataset that is used in the front-end should go down with template file.
	 * However, in the case of JSP, the data should be set to the attribute of the HttpServletRequest object beforehand, before it is go down to the front-end.
	 * 
	 * @param  dataset  The JSON notation string to be bound with template file.
	 * @throws IOException  When the template file can not be read.
	 * @deprecated As of version 1.9, replaced by {@link #resolveContent(String)}, removed from version 2.0
	 */
	public void resolveTemplate(String dataset) throws IOException {
		resolveContent(dataset);
	}

	/**
	 * This method resolves the template file and bind the JSON notation string.
	 * 
	 * In the case of JavaScript-based template file, only the template file is searched in the back-end, and the rendering is performed in the front-end.
	 * Therefore, the dataset that is used in the front-end should go down with template file.
	 * However, in the case of JSP, the data should be set to the attribute of the HttpServletRequest object beforehand, before it is go down to the front-end.
	 * 
	 * @param  dataset   The JSON notation string to be bound with template file.
	 * @param  encoding  The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When the template file can not be read.
	 * @deprecated As of version 1.9, replaced by {@link #resolveContent(String, String)}, removed from version 2.0
	 */
	public void resolveTemplate(String dataset, String encoding) throws IOException {
		resolveContent(dataset, encoding);
	}

	/**
	 * This method resolves the template file with UTF-8 character set.
	 * 
	 * @throws IOException  When the template file can not be read.
	 * @since  1.9
	 */
	public void resolveContent() throws IOException {
		resolveContent((String)null);
	}

	/**
	 * This method resolves the template file with UTF-8 character set and bind the JSON notation string that is converted Java Map object.
	 * 
	 * In the case of JavaScript-based template file, since it is rendered in the front-end,
	 * you need to convert the Java value oject used in the back-end into a JSON Object used in JavaScript.
	 * If you use Map Object with Java value oject, it automatically converts to JSON notation string and goes down to the front-end.
	 * 
	 * In the case of JSP, since it is rendered in the back-end, you can not use the JSON notation string data used in the front-end.
	 * Therefore, in the case of back-end-based template engine like JSP, before you convert the Java value oject to be passed to the front-end into a JSON notation string,
	 * you need the logic to set the Java value object in the attribute of the HttpServletRequest object in advance.
	 * Using Java Map Object data as a parameter, this series of operations is also done automatically.
	 * 
	 * @param  datamap  The Java Map object to be bound with template file.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.9
	 */
	public void resolveContent(Map<String, ?> datamap) throws IOException {
		resolveContent(datamap, null);
	}

	/**
	 * This method resolves the template file and bind the JSON notation string that is converted Java Map object.
	 * 
	 * In the case of JavaScript-based template file, since it is rendered in the front-end,
	 * you need to convert the Java value oject used in the back-end into a JSON Object used in JavaScript.
	 * If you use Map Object with Java value oject, it automatically converts to JSON notation string and goes down to the front-end.
	 * 
	 * In the case of JSP, since it is rendered in the back-end, you can not use the JSON notation string data used in the front-end.
	 * Therefore, in the case of back-end-based template engine like JSP, before you convert the Java value oject to be passed to the front-end into a JSON notation string,
	 * you need the logic to set the Java value object in the attribute of the HttpServletRequest object in advance.
	 * Using Java Map Object data as a parameter, this series of operations is also done automatically.
	 * 
	 * @param  datamap   The Java Map object to be bound with template file.
	 * @param  encoding  The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.9
	 */
	public void resolveContent(Map<String, ?> datamap, String encoding) throws IOException {
		setBindingData(datamap);
		resolveContent(new CommandBridge().toJson(datamap), encoding);
	}

	/**
	 * This method resolves the template file with UTF-8 character set and bind the JSON notation string.
	 * 
	 * In the case of JavaScript-based template file, only the template file is searched in the back-end, and the rendering is performed in the front-end.
	 * Therefore, the dataset that is used in the front-end should go down with template file.
	 * However, in the case of JSP, the data should be set to the attribute of the HttpServletRequest object beforehand, before it is go down to the front-end.
	 * 
	 * @param  dataset  The JSON notation string to be bound with template file.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.9
	 */
	public void resolveContent(String dataset) throws IOException {
		resolveContent(dataset, null);
	}

	/**
	 * This method resolves the template file and bind the JSON notation string.
	 * 
	 * In the case of JavaScript-based template file, only the template file is searched in the back-end, and the rendering is performed in the front-end.
	 * Therefore, the dataset that is used in the front-end should go down with template file.
	 * However, in the case of JSP, the data should be set to the attribute of the HttpServletRequest object beforehand, before it is go down to the front-end.
	 * 
	 * @param  dataset   The JSON notation string to be bound with template file.
	 * @param  encoding  The character set. If null, it is recognized as a UTF-8 character set.
	 * @throws IOException  When the template file can not be read.
	 * @since  1.9
	 */
	public void resolveContent(String dataset, String encoding) throws IOException {
		if (encoding == null)  encoding = "UTF-8";

		String delimiter      = null;
		String delimiterValue = null;
		String templateId     = requestUtil.getTemplateId();

		try {
			if (!(dataset == null || dataset.trim().equals(""))) {
				String plainDelimiter = "Jnode-Response-Delimiter_" + new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());
				delimiter = new String(Base64.getEncoder().encodeToString(plainDelimiter.getBytes(encoding)));
				// delimiter = new String(Base64.encodeBase64(plainDelimiter.getBytes(encoding)));
				delimiterValue = "\"\"''<-------- " + delimiter + " -------->''\"\"";

				response.addHeader("Jnode-Response-Delimiter", delimiter);
			}

			if (templateType.equalsIgnoreCase("html")) {
				String langSubfix = "";

				if (request.getParameter("error.status_code") == null && blang != null) {
					langSubfix = "_" + blang;
				}

				// NOTE: Because I can not catch an error when there is no file through Exception, so I check if the file exists and should change it in a better way.
				RequestDispatcher dispatcher = null;

				if (!langSubfix.equals("") && new File(context.getRealPath(templatePath + templateId + langSubfix + templateExt)).exists()) {
					dispatcher = request.getRequestDispatcher(templatePath + templateId + langSubfix + templateExt);
				} else {
					dispatcher = request.getRequestDispatcher(templatePath + templateId + templateExt);
				}

				if (delimiter == null) {
					dispatcher.forward(request, response);
				} else {
					response.setContentType("text/plain; charset=" + encoding);
					PrintWriter out = response.getWriter();
					out.print(dataset);
					out.print(delimiterValue);

					dispatcher.include(request, response);
				}
			} else {
				String value = getTemplateValue(templateId, encoding, blang);

				response.setContentType("text/plain; charset=" + encoding);
				PrintWriter out = response.getWriter();

				if (delimiter != null) {
					out.print(dataset);
					out.print(delimiterValue);
				}

				out.print(value);
			}
		} catch(NullPointerException e) {
			try {
				if (request.getParameter("error.status_code") == null) {
					this.templateExt  = ".ejs";
					String value      = null;
					String nodeType   = request.getParameter("nodeType");
					Map<String, Object> dataMap = new HashMap<String, Object>();

					try {
						value = getTemplateValue("/content/status/" + nodeType, encoding);
					} catch(NullPointerException npe) {
						value = getTemplateValue("/content/status/default", encoding);
						dataMap.put("status_file", "default");
					}

					Map<String, Object> errorData = new HashMap<String, Object>();
					errorData.put("status_code", 404);
					errorData.put("template"   , "ejs");
					errorData.put("message"    , "The template file for the " + nodeType + " node is not found.");
					errorData.put("stack"      , "The template file for the " + nodeType + " node is not found.");
					errorData.put("request_uri", request.getRequestURI());

					if (request.getAttribute("forward_node_id") != null) {
						errorData.put("forward_node_id", request.getAttribute("forward_node_id"));
					}

					dataMap.put("error", errorData);

					if (delimiter == null) {
						String plainDelimiter = "Jnode-Response-Delimiter_" + new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());
						delimiter = new String(Base64.getEncoder().encodeToString(plainDelimiter.getBytes(encoding)));
						// delimiter = new String(Base64.encodeBase64(plainDelimiter.getBytes(encoding)));
						delimiterValue = "\"\"''<-------- " + delimiter + " -------->''\"\"";

						response.addHeader("Jnode-Response-Delimiter", delimiter);
					}

					response.setContentType("text/plain; charset=" + encoding);
					PrintWriter out = response.getWriter();
					out.print(new CommandBridge().toJson(dataMap));
					out.print(delimiterValue);
					out.print(value);
				} else {
					response.setStatus(404);
				}
			} catch(Exception ex) {
				response.setStatus(500);
			}
		} catch(Exception e) {
			Map<String, Object> dataSet = new HashMap<String, Object>();
			dataSet.put("status_code", 500);
			dataSet.put("message"    , e.getMessage());
			dataSet.put("stack"      , e.getMessage());

			PrintWriter out = response.getWriter();
			out.print(new CommandBridge().toJson(dataSet));

			response.setStatus(500);
		}
	}

	/**
	 * This function creates a directory of the full path including the parent directory.
	 * 
	 * @param   path  Directory file object.
	 * @return  Whether to generate.
	 */
	private boolean makeDirectory(File path) {
		if (path.exists()) {
			return true;
		} else {
			File parentDir = path.getParentFile();
			makeDirectory(parentDir);

			return path.mkdir();
		}
	}

	private void setBindingData(Map<String, ?> dataset) {
		if (templateType.equalsIgnoreCase("html")) {
			Set<String> keySet = dataset.keySet();
			for (String key : keySet) {
				request.setAttribute(key, dataset.get(key));
			}
		} else {
			bindingData = requestUtil.getFormParam();

			Set<String> keySet = dataset.keySet();
			for (String key : keySet) {
				Object value = dataset.get(key);

				if ((value instanceof String    )
				 || (value instanceof Boolean   )
				 || (value instanceof BigDecimal)
				 || (value instanceof BigInteger)
				 || (value instanceof Double    )
				 || (value instanceof Integer   )
				 || (value instanceof Long      )
				 || (value instanceof Float     )
				 || (value instanceof Short     )
				 || (value instanceof Byte      )
				 || (value instanceof Character ))  bindingData.put(key, dataset.get(key));
			}
		}
	}

	/*
	private String escapeRE(String value) {
		Pattern escaper = Pattern.compile("([^a-zA-z0-9])");
		return escaper.matcher(value).replaceAll("\\\\$1");
	}
	*/
}