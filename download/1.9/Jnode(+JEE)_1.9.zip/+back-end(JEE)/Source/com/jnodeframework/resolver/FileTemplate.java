/*
 * @(#)PageTemplate.java  1.9, 2014-10-05
 */
package com.jnodeframework.resolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.common.css.JobDescription;
import com.google.common.css.JobDescriptionBuilder;
import com.google.common.css.SourceCode;
import com.google.common.css.compiler.ast.CssTree;
import com.google.common.css.compiler.ast.GssParser;
import com.google.common.css.compiler.ast.GssParserException;
import com.google.common.css.compiler.passes.CompactPrinter;
import com.google.common.css.compiler.passes.DummyErrorManager;
import com.google.common.css.compiler.passes.PassRunner;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.jscomp.CompilationLevel;
import com.google.javascript.jscomp.Compiler;
import com.google.javascript.jscomp.CompilerOptions;
import com.google.javascript.jscomp.DiagnosticGroups;
import com.google.javascript.jscomp.SourceFile;
import com.jnodeframework.util.RequestUtil;

import org.apache.commons.io.IOUtils;

/**
 * Servlet that templatize and process a file from the path (/WEB-INF/template) managed by the JEE Server.
 * 
 * @version 1.9, 2014-10-05
 * @author  Jeasu Kim
 */
public class FileTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	private ServletContext context = null;

	/**
	 * Templatize and process a file from the path (/WEB-INF/template) managed by the JEE Server.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		context  = request.getServletContext();

		String encoding = getServletConfig().getInitParameter("encoding");
		String contentType = getServletConfig().getInitParameter("content-type");
		if (encoding    == null)  encoding    = "UTF-8";
		if (contentType == null)  contentType = "text/plain";

		RequestUtil requestUtil = new RequestUtil(request);
		String templatePath  = requestUtil.getTemplatePath();
		String rendererURI   = requestUtil.getRendererURI();
		String servletPath   = request.getServletPath();
		String requestFile   = servletPath;
		String compiledFile  = templatePath + "/precompile";
		String strPrecompile = request.getServletContext().getInitParameter("jnode.precompile");

		boolean precompile = false;
		boolean notFound   = false;

		if (strPrecompile != null)  precompile = Boolean.parseBoolean(strPrecompile);

		if (rendererURI == null) {
			compiledFile += servletPath;
		} else {
			String requestFileSubfix = (requestUtil.getCollapseScope().equals("template") ? "/collapse" : "/page") + servletPath;

			if (servletPath.startsWith(rendererURI)) {
				requestFileSubfix = servletPath.substring(rendererURI.length());;
			}

			requestFile = templatePath + requestFileSubfix;
			compiledFile += requestFileSubfix;
		}

		if (!new File(context.getRealPath(requestFile)).exists()) {
			if (requestFile.equals(servletPath)) {
				notFound = true;
			} else if (new File(context.getRealPath(servletPath)).exists()) {
				requestFile = servletPath;
			} else {
				notFound = true;
			}
		}

		if (notFound) {
			response.sendError(404, "Not found");
		} else {
			String value = null;

			boolean existParent = false;
			boolean existFile   = false;

			File fileCompiled = null;

			if (precompile) {
				File fileRequest  = new File(context.getRealPath(requestFile));
				fileCompiled = new File(context.getRealPath(compiledFile));

				existFile = fileCompiled.exists();

				if (existFile && (fileRequest.lastModified() < fileCompiled.lastModified())) {
					try {
						value = IOUtils.toString(context.getResourceAsStream(compiledFile), encoding);
					} catch (NullPointerException e) {
					}
				} else {
					File parentDir = fileCompiled.getParentFile();

					if (parentDir.exists() || makeDirectory(parentDir)) {
						existParent = true;
					} else {
						System.out.println("mkdir(): Permission denied during making directory \"" + parentDir.getCanonicalPath() + "\" for precompile.");
					}
				}
			}

			if (value == null) {
				value = templatizeFile(requestFile, encoding);

				if (existParent) {
					if (existFile || fileCompiled.createNewFile()) {
						IOUtils.write(value, new FileOutputStream(fileCompiled), encoding);
					} else {
						System.out.println("Permission denied during create file \"" + fileCompiled.getCanonicalPath() + "\" for precompile.");
					}
				}
			}

			// text/css, text/javascript
			response.setContentType(contentType + "; charset=" + encoding);
			PrintWriter out = response.getWriter();
			out.print(value);
		}
	}

	private String templatizeFile(String requestFile, String encoding) throws IOException {
		String extension = requestFile.substring(requestFile.lastIndexOf(".") + 1);
		String value = IOUtils.toString(context.getResourceAsStream(requestFile), encoding);

		if (extension.equals("css")) {
			JobDescription job = new JobDescriptionBuilder().getJobDescription();
			PassRunner passRunner = new PassRunner(job, new DummyErrorManager());
	
			SourceCode input = new SourceCode("input.css", value);
			GssParser parser = new GssParser(input);

			try {
				CssTree tree = parser.parse();
				passRunner.runPasses(tree);
	
				CompactPrinter printer = new CompactPrinter(tree);
				printer.runPass();
				return printer.getCompactPrintedString();
			} catch (GssParserException e) {
				return value;
			}
		} else if (extension.equals("js")) {
			SourceFile extern = SourceFile.fromCode("externs.js", "");
			SourceFile input = SourceFile.fromCode("input.js", value);

			CompilerOptions options = new CompilerOptions();
			options.setEmitUseStrict(false);
			options.setWarningLevel(DiagnosticGroups.REPORT_UNKNOWN_TYPES, CheckLevel.OFF);
			options.setWarningLevel(DiagnosticGroups.NON_STANDARD_JSDOC, CheckLevel.OFF);
			CompilationLevel.WHITESPACE_ONLY.setOptionsForCompilationLevel(options);

			Compiler compiler = new Compiler();
			compiler.compile(extern, input, options);

			return compiler.toSource();
		} else {
			/*
			if (isset($this::$JS_EXEC)) {
				// TODO: ~~~~~~~
				// less
				// coffee
			}
			*/

			return value;
		}
	}

	/**
	 * This function creates a directory of the full path including the parent directory.
	 * 
	 * @param   path  Directory file object.
	 * @return  Whether to generate.
	 */
	private boolean makeDirectory(File path) {
		if (path.exists()) {
			return true;
		} else {
			File parentDir = path.getParentFile();
			makeDirectory(parentDir);

			return path.mkdir();
		}
	}
}