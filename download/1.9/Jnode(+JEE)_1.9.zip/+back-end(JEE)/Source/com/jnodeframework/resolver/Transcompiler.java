/*
 * @(#)PageTemplate.java  1.9, 2014-10-05
 */
package com.jnodeframework.resolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// import com.google.common.css.JobDescription;
// import com.google.common.css.JobDescriptionBuilder;
// import com.google.common.css.SourceCode;
// import com.google.common.css.compiler.ast.CssTree;
// import com.google.common.css.compiler.ast.GssParser;
// import com.google.common.css.compiler.ast.GssParserException;
// import com.google.common.css.compiler.passes.CompactPrinter;
// import com.google.common.css.compiler.passes.DummyErrorManager;
// import com.google.common.css.compiler.passes.PassRunner;
import com.google.javascript.jscomp.CheckLevel;
import com.google.javascript.jscomp.CompilationLevel;
import com.google.javascript.jscomp.Compiler;
import com.google.javascript.jscomp.CompilerOptions;
import com.google.javascript.jscomp.DiagnosticGroups;
import com.google.javascript.jscomp.SourceFile;
import com.gurumdari.CommandBridge;
import com.jnodeframework.util.RequestUtil;

import org.apache.commons.io.IOUtils;

/**
 * Servlet that transcompiles the request URI.
 * 
 * @version 1.9, 2014-10-05
 * @author  Jeasu Kim
 * @since   1.9
 */
public class Transcompiler extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	private ServletContext context = null;
	private String tsTarget = null;

	/**
	 * This method transcompiles the request URI.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		context  = request.getServletContext();

		RequestUtil requestUtil = new RequestUtil(request);
		String templatePath  = requestUtil.getTemplatePath();
		String rendererURI   = requestUtil.getRendererURI();
		String servletPath   = request.getServletPath();
		String requestFile   = servletPath;
		String compiledFile  = templatePath + "/precompile";
		String extension     = servletPath.substring(servletPath.lastIndexOf(".") + 1).toLowerCase();
		String contentType   = getServletConfig().getInitParameter("content-type");
		String encoding      = getServletConfig().getInitParameter("encoding");
		String target        = getServletConfig().getInitParameter("target");
		String strMinify     = getServletConfig().getInitParameter("minify");
		String strPrecompile = request.getServletContext().getInitParameter("jnode.precompile");

		boolean minify     = true;
		boolean precompile = false;

		if (contentType == null) {
			if      (extension.equals("css"   ))  contentType = "text/css";
			else if (extension.equals("less"  ))  contentType = "text/css";
			else if (extension.equals("js"    ))  contentType = "text/javascript";
			else if (extension.equals("coffee"))  contentType = "text/javascript";
			else if (extension.equals("ts"    ))  contentType = "text/javascript";
			else                                  contentType = "text/plain";
		} else {
			contentType = contentType.toLowerCase();
		}

		if (encoding == null)  encoding = "UTF-8";

		if (strMinify     != null)  minify     = Boolean.parseBoolean(strMinify);
		if (strPrecompile != null)  precompile = Boolean.parseBoolean(strPrecompile);

		if (contentType.equals("text/javascript")) {
			if (extension.equals("ts")) {
				tsTarget = "es5";

				if (target != null)  tsTarget = target;
			} else if (extension.equals("js")) {
				if ("es5".equalsIgnoreCase(target)) {
					if (precompile) {  // Because all browsers use precompiled files.
						tsTarget = "es5";
					} else {
						String userAgent = request.getHeader("user-agent");

						if (userAgent.indexOf("Trident") > -1 || userAgent.indexOf("MSIE") > -1) {
							tsTarget = "es5";
						}
					}
				}
			}
		}

		if (rendererURI == null) {
			compiledFile += "/page" + servletPath;
		} else {
			String requestFileSubfix = (requestUtil.getCollapseScope().equals("template") ? "/collapse" : "/page") + servletPath;

			if (servletPath.startsWith(rendererURI)) {
				requestFileSubfix = servletPath.substring(rendererURI.length());;
			}

			requestFile = templatePath + requestFileSubfix;
			compiledFile += requestFileSubfix;

			if (!new File(context.getRealPath(requestFile)).exists()) {
				requestFile = servletPath;
			}
		}

		File fileRequest = new File(context.getRealPath(requestFile));

		if (fileRequest.exists()) {
			String value = null;

			boolean existParent = false;
			boolean existFile   = false;

			File fileCompiled = null;

			if (precompile) {
				fileCompiled = new File(context.getRealPath(compiledFile));

				existFile = fileCompiled.exists();

				if (existFile && (fileRequest.lastModified() < fileCompiled.lastModified())) {
					try {
						value = IOUtils.toString(context.getResourceAsStream(compiledFile), encoding);
					} catch (NullPointerException e) {
					}
				} else {
					File parentDir = fileCompiled.getParentFile();

					if (parentDir.exists() || makeDirectory(parentDir)) {
						existParent = true;
					} else {
						System.out.println("mkdir(): Permission denied during making directory \"" + parentDir.getCanonicalPath() + "\" for precompile.");
					}
				}
			}

			if (value == null) {
				String filename4WinServer = null;

				if (tsTarget != null) {
					String osName = System.getProperty("os.name");
		
					if ((osName != null) && osName.startsWith("Windows")) {
						// The cmd of Windows can not use "/dev/stdout", so transcompiled files should be stored.
						if (precompile)  filename4WinServer = compiledFile;
						else             throw new RuntimeException("If the server is Windows and " + (extension.equals("ts") ? "the extension is ts" : "the target of js extension is es5") + ", The jnode.precompile context-param should be true");
					}
				}

				value = trascompileFile(requestFile, extension, encoding, filename4WinServer);

				if (minify)  value = minifyValue(value, contentType);

				if (existParent) {
					if (existFile || fileCompiled.createNewFile()) {
						IOUtils.write(value, new FileOutputStream(fileCompiled), encoding);
					} else {
						System.out.println("Permission denied during create file \"" + fileCompiled.getCanonicalPath() + "\" for precompile.");
					}
				}
			}

			// text/css, text/javascript
			response.setContentType(contentType + "; charset=" + encoding);
			PrintWriter out = response.getWriter();
			out.print(value);
		} else {
			response.sendError(404, "Not found");
		}
	}

	private String trascompileFile(String requestFile, String extension, String encoding, String filename4WinServer) throws IOException {
		if (extension.equals("less")) {
			String[] commands = {
				"lessc",
				context.getRealPath(requestFile)
			};

			return new CommandBridge().call(commands);
		} else if (extension.equals("coffee")) {
			String[] commands = {
				"coffee",
				"-bp",
				context.getRealPath(requestFile)
			};

			return new CommandBridge().call(commands);
		} else if (tsTarget != null) {
			String outFile = "/dev/stdout";
			if (filename4WinServer != null)  outFile = context.getRealPath(filename4WinServer);

			String[] commands = {
				"tsc",
				"--target",
				tsTarget,
				"--outFile",
				outFile,
				"--allowJs",
				context.getRealPath(requestFile)
			};

			if (filename4WinServer == null) {
				return new CommandBridge().call(commands);
			} else {
				new CommandBridge().call(commands);
				return IOUtils.toString(context.getResourceAsStream(filename4WinServer), encoding);
			}
		} else {
			return IOUtils.toString(context.getResourceAsStream(requestFile), encoding);
		}
	}

	private String minifyValue(String value, String contentType) throws IOException {
		if (contentType.equals("text/css")) {
			// Remove comments
			value = value.replaceAll("/\\*+[^*]*\\*+(?:[^/*][^*]*\\*+)*/"," ");

			// Remove whitespace
			value = value.replaceAll("\\s{2,}", " ");

			// Remove space of comma, colons, semicolons and block.
			value = value.replaceAll("\\s*;\\s*}", "}");
			value = value.replaceAll("\\s*(,|:|;|\\{|\\})\\s*", "$1");

			/*
			// There is a bug that removes content.
			JobDescription job = new JobDescriptionBuilder().getJobDescription();
			PassRunner passRunner = new PassRunner(job, new DummyErrorManager());

			SourceCode input = new SourceCode("input.css", value);
			GssParser parser = new GssParser(input);

			try {
				CssTree tree = parser.parse();
				passRunner.runPasses(tree);

				CompactPrinter printer = new CompactPrinter(tree);
				printer.runPass();
				return printer.getCompactPrintedString();
			} catch (GssParserException e) {
				return value;
			}
			*/
		} else if (contentType.equals("text/javascript")) {
			SourceFile extern = SourceFile.fromCode("externs.js", "");
			SourceFile input = SourceFile.fromCode("input.js", value);

			CompilerOptions options = new CompilerOptions();
			options.setEmitUseStrict(false);
			options.setWarningLevel(DiagnosticGroups.REPORT_UNKNOWN_TYPES, CheckLevel.OFF);
			options.setWarningLevel(DiagnosticGroups.NON_STANDARD_JSDOC, CheckLevel.OFF);
			CompilationLevel.WHITESPACE_ONLY.setOptionsForCompilationLevel(options);

			Compiler compiler = new Compiler();
			compiler.compile(extern, input, options);

			return compiler.toSource();

			/*
			value = StringEscapeUtils.escapeJava(value);
			value = value.replaceAll("^\\\\u([A-F0-9]{3})", "\\\\\\\\u$1");
			value = value.replaceAll("([^\\\\])\\\\u([A-F0-9]{3})", "$1\\\\\\\\u$2");
			value = value.replaceAll("([^\\\\])((\\\\\\\\)*)\\\\\\\\\\\\u", "$1$2\\\\\\\\\\\\\\\\u");
			value = StringEscapeUtils.unescapeJava(value);
			*/
		}

		return value;
	}

	/**
	 * This function creates a directory of the full path including the parent directory.
	 * 
	 * @param   path  Directory file object.
	 * @return  Whether to generate.
	 */
	private boolean makeDirectory(File path) {
		if (path.exists()) {
			return true;
		} else {
			File parentDir = path.getParentFile();
			makeDirectory(parentDir);

			return path.mkdir();
		}
	}
}