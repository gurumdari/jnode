<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$headers = $jnode->getRequestHeaders(true);
	$host    = $headers['host'];  // localhost:8080
	$origin  = null;              // http://localhost:8080

	// In Firefox, there is no origin in the header, so treat it as a referer.
	if (array_key_exists('origin', $headers))  $origin = $headers['origin'];
	else                                       $origin = $headers['referer'];

	if ($origin == null || strpos($origin, $host) < 0) {
		// Block requests from other domains.
		$jnode->sendError(403, 'Not allow access from the cross domain');
	}

	function getBase64Image($source_file, string $content_type, int $rewidth = 0, int $reheight) {
		$resizable = preg_match("/^image\/((png)|(jpg)|(jpeg)|(jpe)|(gif))$/i", $content_type, $extension) && extension_loaded('gd');
		$extension = $extension[1];

		if ($extension == 'jpg' || $extension == 'jpe')  $extension = 'jpeg';

		if ($resizable && ($rewidth > 0 || $reheight > 0)) {
			// Get new sizes
			list($width, $height) = getimagesize($source_file);
			$newwidth  = $width;
			$newheight = $height;

			if (($rewidth > 0) && ($rewidth < $newwidth)) {
				$newheight = $newheight * $rewidth / $newwidth;
				$newwidth  = $rewidth;
			}

			if (($reheight > 0) && ($reheight < $newheight)) {
				$newwidth  = $newwidth * $reheight / $newheight;
				$newheight = $reheight;
			}

			// Load
			// sudo apt install php7.0-gd
			$target = imagecreatetruecolor($newwidth, $newheight);
			$source = null;

			if      ($extension == 'png' )  $source = imagecreatefrompng ($source_file);
			else if ($extension == 'jpeg')  $source = imagecreatefromjpeg($source_file);
			else if ($extension == 'gif' )  $source = imagecreatefromgif ($source_file);

			// Resize
			imagecopyresized($target, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

			// Output
			ob_start();

			if      ($extension == 'png' )  imagepng ($target);
			else if ($extension == 'jpeg')  imagejpeg($target);
			else if ($extension == 'gif' )  imagegif ($target);

			$image_value = ob_get_clean();
			return "data:$content_type;base64,".base64_encode($image_value);
		} else {
			return "data:$content_type;base64,".base64_encode(file_get_contents($source_file));
		}
	}

	function serviceProxy($jnode) {
		$jnode_param = array();

		if (count($_GET) > 0) {
			foreach ($_GET as $key => $value) {
				$jnode_param[$key] = $value;
			}
		}

		if ($_SERVER['REQUEST_METHOD'] == 'POST' && count($_POST) > 0) {
			foreach ($_POST as $key => $value) {
				$jnode_param[$key] = $value;
			}
		}

		$target_url = null;
		$rewidth    = 0;
		$reheight   = 0;

		if (array_key_exists('url',      $jnode_param))  $target_url = $jnode_param['url'];
		if (array_key_exists('rewidth',  $jnode_param))  $rewidth    = $jnode_param['rewidth'];
		if (array_key_exists('reheight', $jnode_param))  $reheight   = $jnode_param['reheight'];

		if ($target_url == null)  $jnode->sendError(500, 'The URL address to load is empty');

		if (is_array($target_url))  $target_url = array_shift($jnode_param['url']);
		if (is_array($rewidth)   )  $rewidth    = intval(array_shift($jnode_param['rewidth']));
		if (is_array($reheight)  )  $reheight   = intval(array_shift($jnode_param['reheight']));

		$content_type = get_headers($target_url, 1)['Content-Type'];
		echo getBase64Image($target_url, $content_type, $rewidth, $reheight);
	}

	// file_uploads = On at php.ini
	function seriveClientImageFile($jnode) {
		$jnode_param = array();

		foreach ($_POST as $key => $value) {
			$jnode_param[$key] = $value;
		}

		$forward_uri = null;
		if (array_key_exists('forward_uri', $jnode_param))  $forward_uri = $jnode_param['forward_uri'];

		if ($forward_uri  == null)  $jnode->sendError(500, 'The forward_uri is empty');

		if (is_array($forward_uri))  $forward_uri = array_shift($jnode_param['forward_uri']);
		if (substr($forward_uri, 0, 1) != '/')  $forward_uri = "/$forward_uri";

		$rewidths  = [0];
		$reheights = [0];

		if (array_key_exists('rewidth' , $jnode_param)) {
			$rewidths = $jnode_param['rewidth'];
			if (!is_array($rewidths))  $rewidths = [$rewidths];
		}

		if (array_key_exists('reheight', $jnode_param)) {
			$reheights = $jnode_param['reheight'];
			if (!is_array($reheights))  $reheights = [$reheights];
		}

		$file_keys = array_keys($_FILES);
		$file_count     = count($file_keys);
		$rewidth_count  = count($rewidths);
		$reheight_count = count($reheights);

		for($count = 0; $count < $rewidth_count; $count++){
			$rewidths[$count] = intval($rewidths[$count]);
		}

		for($count = 0; $count < $reheight_count; $count++){
			$reheights[$count] = intval($reheights[$count]);
		}

		for ($count = $rewidth_count; $count < $file_count; $count++) {
			$rewidths[$count] = $rewidths[$rewidth_count - 1];
		}

		for ($count = $reheight_count; $count < $file_count; $count++) {
			$reheights[$count] = $reheights[$reheight_count - 1];
		}

		$index = 0;

		foreach($file_keys as $key) {
			$content_type = $_FILES[$key]['type'];  // image/jpeg
			$base64_image = getBase64Image($_FILES[$key]['tmp_name'], $content_type, $rewidths[$index], $reheights[$index]);

			$jnode_param[$key] = [
				'name' => $_FILES[$key]['name'],
				'value' => $base64_image,
				'contentType' => $content_type,
				'size' => $_FILES[$key]['size']
			];

			$index++;
		}

		$template   = 'html';
		// $page_id    = $forward_uri;
		$page_id    = explode('/$/', $forward_uri)[0];
		$path_index = strrpos($forward_uri, '/');
		$ext_index  = strrpos($forward_uri, '.');

		if (($ext_index === false) || ($path_index > $ext_index)) {
			if (substr($page_id, -1) == '/') {
				$page_id = $page_id."index";
			} else {
				$page_id = "$page_id/index";
			}
		} else {
			$page_id = substr($page_id, 0, $ext_index);
		}

		if (isset($jnode_param['template']))  $template = $jnode_param['template'];

		$jnode->requirePage($page_id, $template, $jnode_param);
	}

	if (count($_FILES) > 0) {
		seriveClientImageFile($jnode);
	} else {
		serviceProxy($jnode);
	}
}