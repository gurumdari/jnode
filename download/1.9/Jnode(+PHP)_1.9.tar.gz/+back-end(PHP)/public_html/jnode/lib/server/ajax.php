<?php
require_once 'autoload.php';

$jnode = new \Gurumdari\Jnode();
$jnode->registMods();

$request_uri_only = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if (__FILE__ == $jnode::$HTML_HOME.$request_uri_only) {
	$jnode->sendError(404);
} else {
	$jnode->requireAJAX();
}