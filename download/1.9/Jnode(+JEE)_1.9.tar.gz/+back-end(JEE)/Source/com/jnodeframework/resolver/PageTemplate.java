/*
 * @(#)PageTemplate.java  1.0, 2014-10-10
 */
package com.jnodeframework.resolver;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet that renders the template file to process a web application page from the path (/WEB-INF/template/page) managed by the JEE Server.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class PageTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The template file to process the page of the web application is found and rendered from the path (/WEB-INF/template/page) managed by JEE Server.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String template = getServletConfig().getInitParameter("template");
		String encoding = getServletConfig().getInitParameter("encoding");

		new TemplateResolver(request, response, template).renderPage((String)null, encoding);
	}
}