/*
 * @(#)FrontendDatasetTemplate.java  1.8, 2017-09-12
 */
package com.jnodeframework.resolver;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet that provides JSON format for use in the front-end from the data used while rendering the template file in the back-end.
 * 
 * @version 1.8, 2017-09-12
 * @author  Jeasu Kim
 * @since   1.8
 */
@WebServlet(urlPatterns = "/jnode/proxy/frontend_dataset.js")
public class FrontendDatasetTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method provides JSON format for use in the front-end from the data used while rendering the template file in the back-end.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String id = request.getParameter("id");

		if (id == null) {
			response.sendError(404, "File Not Found");
		} else {
			HttpSession session = request.getSession();
			@SuppressWarnings("unchecked")
			Map<String, String> dataset = (Map<String, String>)session.getAttribute(id);

			if (dataset == null) {
				response.sendError(404, "File Not Found");
			} else {
				response.setContentType("text/plain; charset=" + dataset.get("encoding"));
				PrintWriter out = response.getWriter();
				out.print("$jnode$.dataset=" + dataset.get("options") + ";$dataset$=$jnode$.dataset;");

				session.removeAttribute(id);

				Cookie cookie = new Cookie("Jnode-Frontend-Id", id);
				cookie.setMaxAge(0);
				cookie.setPath("/");
				response.addCookie(cookie);
			}
		}
	}
}